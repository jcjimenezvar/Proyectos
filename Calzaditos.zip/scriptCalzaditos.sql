CREATE DATABASE CALZADITOS;
USE CALZADITOS;

CREATE TABLE EMPLEADOS(
	ID INT AUTO_INCREMENT PRIMARY KEY,
	IDENTIFICACION VARCHAR(100) NOT NULL,		
	NOMBRES VARCHAR(100) NOT NULL,
	APELLIDOS VARCHAR(100) NOT NULL,
	EDAD INT NOT NULL,
	DIRECCION VARCHAR(100) NOT NULL,
	ESTADO BOOL DEFAULT TRUE NOT NULL,
	CONTRASENA VARCHAR(100) not null,
	ROL Enum ('0','1')
);

INSERT INTO `CALZADITOS`.`empleados` (`id`, `identificacion`, `nombres`, `apellidos`, `edad`, `direccion`, `contrasena`, `rol`) VALUES ('1', '109845678', 'Carlos', 'Medina', '28', 'Cra 21 15-02','123','0');
INSERT INTO `CALZADITOS`.`empleados` (`id`, `identificacion`, `nombres`, `apellidos`, `edad`, `direccion`, `contrasena`, `rol`) VALUES ('2', '2874963', 'Andres', 'Cortes', '25', 'Cra 34 17-80', '123', '1');


CREATE TABLE MENU(
	ID TINYINT PRIMARY KEY,
	NOMBRE_MENU VARCHAR(50) not null,		
	URL VARCHAR(100),
	TIPO_MENU ENUM('S','I') not null,
	ROL_USUARIO ENUM('0','1') not null,
	CODIGO_SUBMENU TINYINT,
	ESTADO BOOL DEFAULT TRUE NOT NULL
);

INSERT INTO MENU (id, nombre_menu,url,tipo_menu, rol_usuario, codigo_submenu)
VALUES 
(1,'Proceo Registro',null,'S','0',null),
(2,'Cliente','/faces/calzaditos/cajeroRol/clientes.xhtml','I','0',1),
(3,'Reparacion','/faces/calzaditos/cajeroRol/reparacion.xhtml','I','0',1),
(4,'Proceso Consulta',null,'S','1',null),
(5,'Cliente','/faces/calzaditos/empleadoRol/consultasCli.xhtml','I','1',4),
(6,'Reparacion','/faces/calzaditos/empleadoRol/consultasRep.xhtml','I','1',4),
(7,'Proceso Consulta',null,'S','0',null),
(8,'Cliente','/faces/calzaditos/cajeroRol/consultasCli.xhtml','I','0',7),
(9,'Reparacion','/faces/calzaditos/cajeroRol/consultasRep.xhtml','I','0',7),
(10,'Informes',null,'S','0',null),
(11,'Generar Informe','/faces/calzaditos/cajeroRol/generarInformes.xhtml','I','0',10);

CREATE TABLE CLIENTES(
	ID INT AUTO_INCREMENT PRIMARY KEY,
	IDENTIFICACION VARCHAR(50) NOT NULL,		
	NOMBRES VARCHAR(100) NOT NULL,
	APELLIDOS VARCHAR(100) NOT NULL,
	FECHA_NACIMIENTO DATE NOT NULL,
	TELEFONO VARCHAR(100) NOT NULL,
	DIRECCION VARCHAR(100) NOT NULL,
	ESTADO BOOL DEFAULT TRUE NOT NULL
);


CREATE TABLE TIPO_CALZADO(
	ID TINYINT AUTO_INCREMENT PRIMARY KEY,
	NOMBRE_CALZADO VARCHAR(50) NOT NULL,		
	ESTADO BOOL DEFAULT TRUE NOT NULL
);

CREATE TABLE REPARACIONES(
	ID TINYINT AUTO_INCREMENT PRIMARY KEY,
	VALOR_REPARACION DOUBLE NOT NULL,
	IDENTIFICACION_CLIENTE VARCHAR(50) NOT NULL,
	DESCRIPCION VARCHAR(200) NOT NULL,		
	ID_TIPO_CALZADO TINYINT NOT NULL,
	ESTADO_REPARACION BOOL DEFAULT TRUE NOT NULL
);

ALTER TABLE REPARACIONES ADD CONSTRAINT FK_ID_TIPO_CALZADO FOREIGN KEY (ID_TIPO_CALZADO) REFERENCES TIPO_CALZADO (ID);

INSERT INTO `CALZADITOS`.`tipo_calzado` (`ID`, `NOMBRE_CALZADO`) VALUES ('1', 'Zapato Dama');
INSERT INTO `CALZADITOS`.`tipo_calzado` (`ID`, `NOMBRE_CALZADO`) VALUES ('2', 'Zapato Caballero');
INSERT INTO `CALZADITOS`.`tipo_calzado` (`ID`, `NOMBRE_CALZADO`) VALUES ('3', 'Tennis');




