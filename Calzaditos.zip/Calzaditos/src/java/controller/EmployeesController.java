package controller;

import facade.EmpleadosFacadeLocal;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import model.Empleados;

@Named
@ViewScoped
public class EmployeesController implements Serializable {

    @EJB
    private EmpleadosFacadeLocal ejbEmpleado;
    private Empleados empleado;

    public Empleados getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleados empleado) {
        this.empleado = empleado;
    }

    @PostConstruct
    public void init() {
        empleado = new Empleados();
    }

    public String iniciarSesion() {
        Empleados em;
        String redireccion = null;
        try {
            em = ejbEmpleado.iniciarSesion(empleado);
            if (em.getEstado() == false) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Usuario inactivi", "El usuario no se encuetra activo para aceder al sistema"));
                redireccion = "/calzaditos/principal?faces-redirect=true";
            }
            if (em != null) {
                FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("empleado", em);
                redireccion = "/calzaditos/principal?faces-redirect=true";
            } else {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Usuario o contraseña incorrecta", ""));
            }
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", ""));
        }
        return redireccion;
    }

}
