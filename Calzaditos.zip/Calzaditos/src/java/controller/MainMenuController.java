package controller;

import facade.MenuFacadeLocal;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import model.Menu;
import model.Empleados;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;

@Named
@SessionScoped
public class MainMenuController implements Serializable {

    @EJB
    private MenuFacadeLocal menuEJB;
    private List<Menu> lista;
    private MenuModel model;
    private String nombreEmpleado;

    @PostConstruct
    public void init() {
        Empleados emp = new Empleados();
        this.listarMenus(emp);
        model = new DefaultMenuModel();
        this.establecerPermisos();
    }

    public void listarMenus(Empleados emp) {
        try {
            lista = menuEJB.findAll();

        } catch (Exception e) {
            throw e;
        }
    }

    public List<Menu> getLista() {
        return lista;
    }

    public void setLista(List<Menu> lista) {
        this.lista = lista;
    }

    public MenuModel getModel() {
        return model;
    }

    public void setModel(MenuModel model) {
        this.model = model;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public void establecerPermisos() {
        Empleados emp = (Empleados) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("empleado");
        nombreEmpleado = emp.getNombres() + " " + emp.getApellidos();
        lista.forEach((m) -> {
            if (m.getTipoMenu().equals("S") && m.getRolUsuario().equals(emp.getRol())) {
                DefaultSubMenu subMenu = new DefaultSubMenu(m.getNombreMenu());
                lista.forEach((i) -> {
                    Menu submenu = i.getSubMenu();
                    if (submenu != null) {
                        if (submenu.getId() == m.getId()) {
                            DefaultMenuItem item = new DefaultMenuItem(i.getNombreMenu());
                            item.setUrl(i.getUrl());
                            subMenu.addElement(item);
                        }
                    }
                });
                model.addElement(subMenu);
            }
        });
    }

    public void cerrarSesion() {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
    }

}
