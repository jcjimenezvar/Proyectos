package controller;

import facade.ReparacionesFacadeLocal;
import facade.TipoCalzadoFacadeLocal;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import model.Reparaciones;
import model.TipoCalzado;

@Named
@SessionScoped
public class RegisterRepairsController implements Serializable {

    @EJB
    private ReparacionesFacadeLocal ejbReparacion;
    @EJB
    private TipoCalzadoFacadeLocal ejbTipoCalzado;
    private Reparaciones reparaciones;
    private List<TipoCalzado> listaTipoCalzado;
    private final boolean ESTADO_REPARACION = true;
    private String tipoCalzado;
    private TipoCalzado tipoCalzadoObject;
    private String valorReparacion;

    public Reparaciones getReparaciones() {
        return reparaciones;
    }

    public void setReparaciones(Reparaciones reparaciones) {
        this.reparaciones = reparaciones;
    }

    public List<TipoCalzado> getListaTipoCalzado() {
        return listaTipoCalzado;
    }

    public void setListaTipoCalzado(List<TipoCalzado> listaTipoCalzado) {
        this.listaTipoCalzado = listaTipoCalzado;
    }

    public String getTipoCalzado() {
        return tipoCalzado;
    }

    public void setTipoCalzado(String tipoCalzado) {
        this.tipoCalzado = tipoCalzado;
    }

    public TipoCalzado getTipoCalzadoObject() {
        return tipoCalzadoObject;
    }

    public void setTipoCalzadoObject(TipoCalzado tipoCalzadoObject) {
        this.tipoCalzadoObject = tipoCalzadoObject;
    }

    public String getValorReparacion() {
        return valorReparacion;
    }

    public void setValorReparacion(String valorReparacion) {
        this.valorReparacion = valorReparacion;
    }

    @PostConstruct
    public void init() {
        reparaciones = new Reparaciones();
        tipoCalzadoObject = new TipoCalzado();
        listaTipoCalzado = ejbTipoCalzado.findAll();
    }

    public void registrarReparacion() {
        try {
            tipoCalzadoObject.setId(Short.parseShort(tipoCalzado));
            reparaciones.setValorReparacion(Double.parseDouble(valorReparacion));
            reparaciones.setIdTipoCalzado(tipoCalzadoObject);
            reparaciones.setEstadoReparacion(ESTADO_REPARACION);
            ejbReparacion.create(reparaciones);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro Correcto", "Se registro correctamente la reparación"));
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Error", "Error registrando la reparación"));
        }
    }

}
