/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import model.Reparaciones;
import model.ReparacionesPorCliente;

/**
 *
 * @author Eddie Leudo
 */
@Stateless
public class ReparacionesFacade extends AbstractFacade<Reparaciones> implements ReparacionesFacadeLocal {

    @PersistenceContext(unitName = "CalzaditosPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ReparacionesFacade() {
        super(Reparaciones.class);
    }

    @Override
    public boolean delete(ReparacionesPorCliente r) {
        boolean eliminado = false;
        String consulta;
        int resultado = 0;
        try {
            consulta = "DELETE FROM Reparaciones r WHERE r.id=?1";
            Query query = em.createQuery(consulta);
            query.setParameter(1, r.getId());
            resultado = query.executeUpdate();
            if (resultado > 0) {
                eliminado = true;
            }
        } catch (Exception e) {
            System.out.println("Error eliminando la reparación " + e.getMessage());
        }
        return eliminado;

    }

}
