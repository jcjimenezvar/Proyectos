/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.TipoCalzado;

/**
 *
 * @author Eddie Leudo
 */
@Stateless
public class TipoCalzadoFacade extends AbstractFacade<TipoCalzado> implements TipoCalzadoFacadeLocal {

    @PersistenceContext(unitName = "CalzaditosPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TipoCalzadoFacade() {
        super(TipoCalzado.class);
    }
    
}
