﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EncuestaDeporte
{
    class Encuesta
    {
        static void Main(string[] args)
        {
            int encuestados = 0;
            int si = 0;
            int no = 0;
            Console.WriteLine("Ingrese la cantidad de encuestados");
            encuestados = int.Parse(Console.ReadLine());
            while (encuestados != 0)
            {
                Console.WriteLine("¿Hace usted deporte?");
                string rta = Console.ReadLine();
                if (rta.Equals("S") || rta.Equals("s"))
                {
                    si++;
                    encuestados--;
                }
                else if(rta.Equals("N") || rta.Equals("n"))
                {
                    no++;
                    encuestados--;
                }
                else
                {
                    Console.WriteLine("El valor ingresado no es valido");
                }
                
            }
            Console.WriteLine("De total de encuestados, obtuvimos los siguientes resultados");
            Console.WriteLine("Si: "+si);
            Console.WriteLine("No: " +no);
            Console.ReadKey();

        }
    }
}
