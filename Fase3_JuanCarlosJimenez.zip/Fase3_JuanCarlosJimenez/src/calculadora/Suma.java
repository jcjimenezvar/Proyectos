package calculadora;

public class Suma extends Calculadora {

	private int resultado;

	public int getResultado() {
		return resultado;
	}

	public void setResultado(int resultado) {
		this.resultado = resultado;
	}

	public Suma(int numero1, int numero2, int resultado) {
		super(numero1, numero2);
		this.resultado = resultado;
	}
	
	public void sumar(int numero1, int numero2) {
		int resultado = numero1+numero2;
		setResultado(resultado);
	}

}
