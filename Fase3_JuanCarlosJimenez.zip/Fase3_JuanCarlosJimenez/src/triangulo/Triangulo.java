package triangulo;

import java.util.Scanner;

public class Triangulo {

	Scanner sc = new Scanner(System.in);

	private double medidaLado1;
	private double medidaLado2;
	private double medidaLado3;
	private boolean equilatero;
	private boolean lado1Mayor;
	private boolean lado2Mayor;
	private boolean lado3Mayor;
	private boolean ladosIguales;
	private boolean datosRegistrados;
	private boolean medidasComparadas;

	public boolean isMedidasComparadas() {
		return medidasComparadas;
	}

	public void setMedidasComparadas(boolean medidasComparadas) {
		this.medidasComparadas = medidasComparadas;
	}

	public boolean isDatosRegistrados() {
		return datosRegistrados;
	}

	public void setDatosRegistrados(boolean datosRegistrados) {
		this.datosRegistrados = datosRegistrados;
	}

	public boolean isLadosIguales() {
		return ladosIguales;
	}

	public void setLadosIguales(boolean ladosIguales) {
		this.ladosIguales = ladosIguales;
	}

	public boolean isEquilatero() {
		return equilatero;
	}

	public boolean isLado1Mayor() {
		return lado1Mayor;
	}

	public void setLado1Mayor(boolean lado1Mayor) {
		this.lado1Mayor = lado1Mayor;
	}

	public boolean isLado2Mayor() {
		return lado2Mayor;
	}

	public void setLado2Mayor(boolean lado2Mayor) {
		this.lado2Mayor = lado2Mayor;
	}

	public boolean isLado3Mayor() {
		return lado3Mayor;
	}

	public void setLado3Mayor(boolean lado3Mayor) {
		this.lado3Mayor = lado3Mayor;
	}

	public void setEquilatero(boolean equlatero) {
		this.equilatero = equlatero;
	}

	public double getMedidaLado1() {
		return medidaLado1;
	}

	public void setMedidaLado1(double medidaLado1) {
		this.medidaLado1 = medidaLado1;
	}

	public double getMedidaLado2() {
		return medidaLado2;
	}

	public void setMedidaLado2(double medidaLado2) {
		this.medidaLado2 = medidaLado2;
	}

	public double getMedidaLado3() {
		return medidaLado3;
	}

	public void setMedidaLado3(double medidaLado3) {
		this.medidaLado3 = medidaLado3;
	}

	public static void main(String[] args) {
		Triangulo triangulo = new Triangulo();
		triangulo.mostrarOpciones();
	}

	public void inicializar() {
		boolean datosRegistrados = false;
		System.out.println("Ingrese la medida del lado uno");
		double lado1 = sc.nextDouble();
		setMedidaLado1(lado1);
		System.out.println("Ingrese la medida del lado dos");
		double lado2 = sc.nextDouble();
		setMedidaLado2(lado2);
		System.out.println("Ingrese la medida del lado tres");
		double lado3 = sc.nextDouble();
		setMedidaLado3(lado3);
		datosRegistrados = true;
		setDatosRegistrados(datosRegistrados);
	}

	public void ladoMayor() {
		boolean lado1Mayor = false;
		boolean lado2Mayor = false;
		boolean lado3Mayor = false;
		boolean ladosIguales = false;
		boolean medidasComparadas = false;
		if (getMedidaLado1() > getMedidaLado2() && getMedidaLado1() > getMedidaLado3()) {
			lado1Mayor = true;
			setLado1Mayor(lado1Mayor);
		} else if (getMedidaLado2() > getMedidaLado1() && getMedidaLado2() > getMedidaLado3()) {
			lado2Mayor = true;
			setLado2Mayor(lado2Mayor);
		} else if (getMedidaLado3() > getMedidaLado1() && getMedidaLado3() > getMedidaLado2()) {
			lado3Mayor = true;
			setLado3Mayor(lado3Mayor);
		} else {
			ladosIguales = true;
			setLadosIguales(ladosIguales);
		}
		medidasComparadas = true;
		setMedidasComparadas(medidasComparadas);
	}

	public void equilatero() {
		boolean equilatero = false;
		if (isLadosIguales()) {
			equilatero = true;
			setEquilatero(equilatero);
		} else {
			setEquilatero(equilatero);
		}
	}

	public void imprimir() {
		System.out.println("**********************************");
		System.out.println(" Los datos del triangulo son:     ");
		System.out.println(" Lado 1 : " + getMedidaLado1());
		System.out.println(" Lado 2 : " + getMedidaLado2());
		System.out.println(" Lado 3 : " + getMedidaLado3());
		if (isLado1Mayor()) {
			System.out.println(" El lado 1 es mayor con una medida de " + getMedidaLado1());
		} else if (isLado2Mayor()) {
			System.out.println(" El lado 2 es mayor con una medida de " + getMedidaLado2());
		} else if (isLado3Mayor()) {
			System.out.println(" El lado 3 es mayor con una medida de " + getMedidaLado3());
		} else {
			System.out.println(" Todos los lados tienen la misma medida");
		}
		if (isEquilatero()) {
			System.out.println(" El triangulo es equilatero ya que la medida de sus lados son iguales");
		} else {
			System.out.println(" El triangulo no es equilatero ya que la medida de sus lados es diferente");
		}
		reiniciarValores();
	}

	public void mostrarOpciones() {
		int opc = 0;
		do {
			System.out.println("*********************************");
			System.out.println("1. Registrar datos triangulo     ");
			System.out.println("2. Validar lado mayor triangulo  ");
			System.out.println("3. Triangulo Equilatero          ");
			System.out.println("4. Mostrar datos triangulo       ");
			System.out.println("5. Salir                         ");
			System.out.println("*********************************");
			System.out.println("Seleccione la acci�n a realizar  ");
			System.out.println("*********************************");
			opc = sc.nextInt();
			switch (opc) {
			case 1:
				inicializar();
				break;
			case 2:
				if (!isDatosRegistrados()) {
					System.out.println("Debe registrar los datos para ejecutar esta opci�n");
					continue;
				} else {
					ladoMayor();
				}
				break;
			case 3:
				if (!isMedidasComparadas()) {
					System.out.println("Debe validar las medidas del triangulo en la opci�n 2");
					continue;
				} else {
					equilatero();
				}
				break;
			case 4:
				if (!isMedidasComparadas() && !isDatosRegistrados()) {
					System.out.println(
							"Actualmente no hay datos registrados, debe ingresar los valores y ejecutar los pasos 1,2,3, para poder imprimir los datos del triangulo");
					continue;
				} else {
					imprimir();
				}
				break;
			case 5:
				System.out.println("Gracias por utilizar el programa, hasta pronto");
				break;
			default:
				System.out.println("Seleccione una opci�n valida del menu");
				break;
			}
		} while (opc != 5);

	}
	
	public void reiniciarValores() {
		setDatosRegistrados(false);
		setEquilatero(false);
		setLado1Mayor(false);
		setLado2Mayor(false);
		setLado3Mayor(false);
		setLadosIguales(false);
		setMedidasComparadas(false);
	}

}
