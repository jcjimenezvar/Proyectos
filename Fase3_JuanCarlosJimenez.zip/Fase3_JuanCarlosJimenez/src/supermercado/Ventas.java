package supermercado;

public class Ventas extends Productos{

	
	
	
	
	

}
