package supermercado;

public class Compras extends Productos {
	
	

	

}
