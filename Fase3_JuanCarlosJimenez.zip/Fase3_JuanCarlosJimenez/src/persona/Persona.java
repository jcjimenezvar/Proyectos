package persona;

import java.util.Scanner;

public class Persona {

	Scanner sc = new Scanner(System.in);

	private String nombre;
	private String apellido;
	private int edad;
	private boolean mayorEdad;

	public boolean isMayorEdad() {
		return mayorEdad;
	}

	public void setMayorEdad(boolean mayorEdad) {
		this.mayorEdad = mayorEdad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public static void main(String[] args) {
		Persona persona = new Persona();
		persona.mostrarOpciones();
	}

	public void inicializar() {
		System.out.println("Ingrese el nombre de la persona");
		String nombre = sc.next();
		setNombre(nombre);
		System.out.println("Ingrese el apellido de la persona");
		String apellido = sc.next();
		setApellido(apellido);
		System.out.println("Ingrese la edad de la persona");
		int edad = sc.nextInt();
		setEdad(edad);
	}

	public void imprimir() {
		System.out.println("**********************************");
		System.out.println(" Los datos de la persona son:     ");
		System.out.println(" Nombre :" + getNombre());
		System.out.println(" Apellido :" + getApellido());
		System.out.println(" Edad :" + getEdad());
		if (isMayorEdad()) {
			System.out.println(" Mayor de edad : Si");
		} else {
			System.out.println(" Mayor de edad : No");
		}
	}

	public void esMayorDeEdad() {
		int edad = getEdad();
		boolean mayorEdad = false;
		if (edad >= 18) {
			mayorEdad = true;
			setMayorEdad(mayorEdad);
		} else {
			setMayorEdad(mayorEdad);
		}
	}

	public void mostrarOpciones() {
		int opc = 0;
		do {
			System.out.println("*********************************");
			System.out.println("1. Registrar datos persona       ");
			System.out.println("2. Validar Mayor de edad         ");
			System.out.println("3. Mostrar Datos                 ");
			System.out.println("4. Salir                         ");
			System.out.println("*********************************");
			System.out.println("Seleccione la acci�n a realizar  ");
			System.out.println("*********************************");
			opc = sc.nextInt();
			switch (opc) {
			case 1:
				inicializar();
				break;
			case 2:
				esMayorDeEdad();
				break;
			case 3:
				imprimir();
				break;
			case 4:
				System.out.println("Gracias por utilizar el programa, hasta pronto");
				break;
			default:
				System.out.println("Seleccione una opci�n valida del menu");
				break;
			}
		} while (opc != 4);
	}

}
