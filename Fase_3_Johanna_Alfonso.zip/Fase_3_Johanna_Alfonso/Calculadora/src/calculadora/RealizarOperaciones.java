package calculadora;

public class RealizarOperaciones {

	private int num1;
	private int num2;

	public int getNum1() {
		return num1;
	}

	public void setNum1(int num1) {
		this.num1 = num1;
	}

	public int getNum2() {
		return num2;
	}

	public void setNum2(int num2) {
		this.num2 = num2;
	}

	public int sumar(int numero1, int numero2) {
		int resultado = numero1 + numero2;
		return resultado;
	}

	public int restar(int numero1, int numero2) {
		int resultado = numero1 - numero2;
		return resultado;
	}

	public int multiplicar(int numero1, int numero2) {
		int resultado = numero1 * numero2;
		return resultado;
	}

	public int dividir(int numero1, int numero2) {
		int resultado = numero1 / numero2;
		return resultado;
	}

	

}
