//Desarrollado por Johanna Katherine Alfonso

package calculadora;

import java.util.Scanner;

public class Calculadora extends RealizarOperaciones{

	Scanner entrada = new Scanner(System.in);
	
	public static void main(String[] args) {
		Calculadora cal = new Calculadora();
		cal.mostrarOpciones();
	}

	public void mostrarOpciones() {
		int opc = 0;
		int valor = 0;
		do {
			System.out.println("**********************************");
			System.out.println("**********  Calculadora  *********");
			System.out.println("**********************************");
			System.out.println("1. Realizar suma                  ");
			System.out.println("2. Realizar resta                 ");
			System.out.println("3. Realizar multiplicacion        ");
			System.out.println("4. Realizar Divisi�n              ");
			System.out.println("5. Salir del programa             ");
			System.out.println("**********************************");
			System.out.println("Seleccione                        ");
			System.out.println("**********************************");
			opc = entrada.nextInt();
			switch (opc) {
			case 1:
				solicitarNumeros();				
				valor = sumar(getNum1(), getNum2());
				System.out.println(valor);
				break;
			case 2:
				solicitarNumeros();				
				valor = restar(getNum1(), getNum2());
				System.out.println(valor);
				break;
			case 3:
				solicitarNumeros();				
				valor = multiplicar(getNum1(), getNum2());
				System.out.println(valor);
				break;
			case 4:
				solicitarNumeros();				
				if (getNum2() == 0) {
					System.out.println("No se puede realizar divisi�n entre 0");
					continue;
				} else {
					valor = dividir(getNum1(), getNum2());
					System.out.println(valor);
				}
				break;
			case 5:
				System.out.println("Gracias, hasta pronto");
				break;
			default:
				System.out.println("El valor ingresado "+opc+" no es una opci�n valida del menu");
				break;
			}
		} while (opc != 5);

	}

	public void solicitarNumeros() {
		System.out.println("Ingrese el numero 1");
		int num1 = entrada.nextInt();
		setNum1(num1);
		System.out.println("Ingrese el numero 2");
		int num2 = entrada.nextInt();
		setNum2(num2);
	}

}
