package persona;

import java.util.Scanner;

public class Persona extends PersonaDto{

	Scanner sc = new Scanner(System.in);	

	public static void main(String[] args) {
		Persona persona = new Persona();
		persona.mostrarOpciones();
	}

	public void inicializarDatos() {
		System.out.println("Ingrese el nombre ");
		String nombre = sc.next();
		setNombre(nombre);
		System.out.println("Ingrese el apellido ");
		String apellido = sc.next();
		setApellido(apellido);
		System.out.println("Ingrese la edad de la persona");
		int edad = sc.nextInt();
		setEdad(edad);
	}

	public void imprimir() {
		System.out.println("**********************************");
		System.out.println(" Los datos son:     ");
		System.out.println(" Nombre :" + getNombre());
		System.out.println(" Apellido :" + getApellido());
		System.out.println(" Edad :" + getEdad());
		if (isMayorEdad()) {
			System.out.println(" Mayor de edad : Si");
		} else {
			System.out.println(" Mayor de edad : No");
		}
	}

	public void esMayorDeEdad() {
		int edad = getEdad();
		boolean mayorEdad = false;
		if (edad >= 18) {
			mayorEdad = true;
			setMayorEdad(mayorEdad);
		} else {
			setMayorEdad(mayorEdad);
		}
	}

	public void mostrarOpciones() {
		int opc = 0;
		do {
			System.out.println("*********************************");
			System.out.println("1. Registrar datos               ");
			System.out.println("2. Mayor de edad                 ");
			System.out.println("3. Mostrar Datos                 ");
			System.out.println("4. Salir                         ");
			System.out.println("*********************************");
			System.out.println(" Seleccione                      ");
			System.out.println("*********************************");
			opc = sc.nextInt();
			switch (opc) {
			case 1:
				inicializarDatos();
				break;
			case 2:
				esMayorDeEdad();
				break;
			case 3:
				imprimir();
				break;
			case 4:
				System.out.println("Gracias, hasta pronto");
				break;
			default:
				System.out.println("El valor ingresado "+opc+" no es una opci�n valida del menu");
				break;
			}
		} while (opc != 4);
	}

}
