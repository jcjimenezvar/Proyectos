package supermercado;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import comprasdao.Compras;
import productosdao.ProductosDao;
import productosdto.Productos;
import ventasdao.Ventas;

public class Principal extends ProductosDao {

	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		Principal p = new Principal();
		p.showMainMenu();
	}

	public void showMainMenu() {
		int opc = 0;
		do {
			System.out.println("|*******************************|");
			System.out.println("|1. Registrar Productos         |");
			System.out.println("|2. Registrar Venta             |");
			System.out.println("|3. Registrar Compra            |");
			System.out.println("|4. Calcular ventas d�a         |");
			System.out.println("|5. Salir                       |");
			System.out.println("|*******************************|");
			System.out.println("|Seleccione la opci�n a ejecutar|");
			System.out.println("|*******************************|");
			opc = sc.nextInt();
			switch (opc) {
			case 1:
				List<Productos> setValues = setValues();
				ProductosDao p = new ProductosDao();
				String productName = "";
				double productPrice = 0;
				int quantity = 0;
				for (Productos list : setValues) {
					productName = list.getNameProduct();
					productPrice = list.getPrice();
					quantity = list.getQuantity();
				}
				boolean registerProducts = p.registerProducts(productName, productPrice, quantity);
				if (registerProducts) {
					System.out.println("Producto registrado correctamente");
				} else {
					System.out.println("Ocurrio un error registrando el producto");
				}
				break;
			case 2:
				List<Productos> informationSale = getInformationSale();
				Ventas sales = new Ventas();
				int productCode = 0;
				int productsQuantity = 0;
				ProductosDao products = new ProductosDao();
				for (Productos prod : informationSale) {
					productCode = prod.getCodeProduct();
					productsQuantity = prod.getQuantity();
				}
				double valueSale = calculateValue(productCode, productsQuantity);
				System.out.println("|************************************|");
				System.out.println("| El valor de la venta fue de $" + valueSale + " ");
				System.out.println("|************************************|");
				boolean insertInformationSale = sales.insertInformationSale(productCode, valueSale, productsQuantity);
				if (insertInformationSale) {
					products.updateProductsQuantity(productCode, productsQuantity);
					System.out.println("Se registro la venta correctamente");
				} else {
					System.out.println("Ocurrio un error registrando la venta");
				}
				break;
			case 3:
				List<Productos> list = setInformationPurchase();
				Compras pur = new Compras();
				int purchaseProductCode = 0;
				int purchaseQuantity = 0;
				double totalPurchase = 0;
				String purchaseProductName = "";
				for (Productos purchase : list) {
					purchaseProductName = purchase.getNameProduct();
					if (purchaseProductName != null) {
						boolean register = registerProducts(purchase.getNameProduct(), purchase.getPrice(),
								purchase.getQuantity());
						if (register) {
							System.out.println("Se registro correctamente el producto");
						} else {
							System.out.println("Ocurrio un error registrando el producto");
							break;
						}
					} else {
						updateProductsQuantityPurchases(purchase.getCodeProduct(), purchase.getQuantity());
					}
					if (purchase.getCodeProduct() == 0) {
						purchaseProductCode = maxId();
					}
					purchaseQuantity = purchase.getQuantity();
					totalPurchase = purchase.getPrice();
				}
				pur.insertarInformacionCompra(purchaseProductCode, totalPurchase, purchaseQuantity);
				break;
			case 4:
				Compras purchasesObject = new Compras();
				Ventas salesObject = new Ventas();
				double valuePurchases = purchasesObject.getValuePurchases();
				double valueSales = salesObject.getValueSales();
				System.out.println("|************************************|");
				System.out.println("|         Resumen D�a                |");
				System.out.println("|************************************|");
				System.out.println("| Total ventas: $" + valueSales + "");
				System.out.println("|************************************|");
				System.out.println("| Total compras: $" + valuePurchases + "");
				System.out.println("|************************************|");
				System.out.println("|************************************|");
				System.out.println("| Total : $" + (valuePurchases - valueSales) + "");
				System.out.println("|************************************|");
				break;
			case 5:
				System.out.println("|************************************|");
				System.out.println("| Hasta pronto                       |");
				System.out.println("|************************************|");
				break;
			default:
				System.out.println("|************************************|");
				System.out.println("|Seleccione una opci�n valida        |");
				System.out.println("|************************************|");
				break;
			}

		} while (opc != 5);
	}

	public List<Productos> setValues() {
		Productos p = new Productos();
		List<Productos> values = new ArrayList<>();
		System.out.println("|************************************|");
		System.out.println("| Ingrese el nombre del producto     |");
		System.out.println("|************************************|");
		String productName = sc.next();
		p.setNameProduct(productName);
		System.out.println("|************************************|");
		System.out.println("| Ingrese el precio del producto     |");
		System.out.println("|************************************|");
		double productPrice = sc.nextDouble();
		p.setPrice(productPrice);
		System.out.println("|************************************|");
		System.out.println("| Ingrese la cantidad disponible     |");
		System.out.println("|************************************|");
		int quantity = sc.nextInt();
		p.setQuantity(quantity);
		values.add(p);
		return values;
	}

	public List<Productos> getInformationSale() {
		Productos p = new Productos();
		List<Productos> informationSale = new ArrayList<>();
		System.out.println("|************************************|");
		System.out.println("| Ingrese el codigo del producto     |");
		System.out.println("|************************************|");
		int productCode = sc.nextInt();
		p.setCodeProduct(productCode);
		System.out.println("|************************************|");
		System.out.println("| Ingrese la cantidad de articulos   |");
		System.out.println("|************************************|");
		int quantity = sc.nextInt();
		p.setQuantity(quantity);
		informationSale.add(p);
		return informationSale;
	}

	public List<Productos> setInformationPurchase() {
		List<Productos> list = new ArrayList<>();
		System.out.println("|******************************************|");
		System.out.println("| Digite N o E seg�n corresponda           |");
		System.out.println("|******************************************|");
		System.out.println("| Es un producto nuevo(N) o existente(E)?  |");
		System.out.println("|******************************************|");
		String answer = sc.next().toUpperCase();
		if (answer.equals("N")) {
			list = setValues();
		} else {
			Productos p = new Productos();
			System.out.println("|******************************************|");
			System.out.println("| Ingrese el codigo del producto           |");
			System.out.println("|******************************************|");
			int productCode = sc.nextInt();
			p.setCodeProduct(productCode);
			System.out.println("|********************************************|");
			System.out.println("| Ingrese la cantidad de articulos comprados |");
			System.out.println("|********************************************|");
			int quantity = sc.nextInt();
			p.setQuantity(quantity);
			double purchaseValue = calculateValue(productCode, quantity);
			p.setPrice(purchaseValue);
			list.add(p);
		}
		return list;
	}

}
