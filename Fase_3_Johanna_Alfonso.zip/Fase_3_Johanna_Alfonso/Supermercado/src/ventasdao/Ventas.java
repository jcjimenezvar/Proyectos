package ventasdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Conexion.Conexion;
import productosdto.Productos;

public class Ventas extends Productos{

	public boolean insertInformationSale(int productCode, double valueSale, int quantity) {
		boolean registeredSale = false;
		String sql = "INSERT INTO VENTAS (CODIGO_PRODUCTO, PRECIO_VENTA, CANTIDAD_VENDIDA) VALUES ('" + productCode + "',"
				+ valueSale + "," + quantity + ")";
		try (Connection conn = Conexion.realizarConexion(); PreparedStatement ps = conn.prepareStatement(sql);) {
			int resultado = ps.executeUpdate();
			if (resultado == 1) {
				registeredSale = true;
			}
		} catch (Exception e) {
			System.out.println("Ocurrio un error realizando el registro de la venta " + e.getMessage());
		}
		return registeredSale;
	}
	
	public double getValueSales() {
		double valueSales = 0;
		String sql = "SELECT SUM(PRECIO_VENTA) FROM VENTAS";
		try(Connection conn = Conexion.realizarConexion();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()){
			while(rs.next()) {
				valueSales = rs.getInt(1);
			}
		}catch (Exception e) {
			System.out.println("Ocurrio un error consultando el valor de las ventas " + e.getMessage());
		}
		return valueSales;
	}

}
