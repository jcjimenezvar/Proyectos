package productosdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Conexion.Conexion;
import productosdto.Productos;

public class ProductosDao {

	public boolean registerProducts(String productName, double priceProduct, int quantityAvailable) {
		boolean registered = false;
		String sql = "INSERT INTO PRODUCTOS (NOMBRE_PRODUCTO, PRECIO_PRODUCTO, CANTIDAD_DISPONIBLE)" + " VALUES ('"
				+ productName + "','" + priceProduct + "','" + quantityAvailable + "')";
		try (Connection conn = Conexion.realizarConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {
			int result = ps.executeUpdate();
			if (result == 1) {
				registered = true;
			}
		} catch (Exception e) {
			System.out.println("Error insertando la informaci�n del producto " + e.getMessage());
		}
		return registered;
	}

	public void updateProductsQuantity(int productCode, int quantity) {
		Productos p = new Productos();
		int productsQuantity = getProductsQuantity(productCode);
		p.setQuantity(productsQuantity);
		String sql = "UPDATE PRODUCTOS SET CANTIDAD_DISPONIBLE= (" + (productsQuantity - quantity)
				+ ") WHERE CODIGO_PRODUCTO= " + productCode + "";
		try (Connection conn = Conexion.realizarConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.executeUpdate();
		} catch (Exception e) {
			System.out.println("Error actualizando la cantidad de productos " + e.getMessage());
		}

	}

	public int getProductsQuantity(int productCode) {
		int quantity = 0;
		String sql = "SELECT CANTIDAD_DISPONIBLE FROM PRODUCTOS WHERE CODIGO_PRODUCTO='" + productCode + "'";
		try (Connection conn = Conexion.realizarConexion();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				quantity = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println("Error consultando la cantidad de productos " + e.getMessage());
		}
		return quantity;
	}
	
	public double calculateUnitValue(double total, int quantity) {
		double valueProduct = (total / quantity);
		return valueProduct;
	}
	
	public int maxId() {
		int max = 0;
		String sql ="SELECT MAX(CODIGO_PRODUCTO) FROM PRODUCTOS";
		try (Connection conn = Conexion.realizarConexion();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()){
			while(rs.next()) {
				max = rs.getInt(1);
			}
		}catch (Exception e) {
			System.out.println("Error obteniendo el m�ximo elemento " + e.getMessage());
		}
		return max;
	}
	
	public double getProductPrice(int productCode) {
		double valueProductDB = 0;
		String sql = "SELECT PRECIO_PRODUCTO FROM PRODUCTOS WHERE CODIGO_PRODUCTO='" + productCode + "'";
		try (Connection conn = Conexion.realizarConexion();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				valueProductDB = rs.getDouble("PRECIO_PRODUCTO");
			}
		} catch (Exception e) {
			System.out.println("Error obteniendo el precio del producto " + e.getMessage());
		}
		return valueProductDB;

	}
	
	public double calculateValue(int productCode, int quantity) {
		double valueProduct = (getProductPrice(productCode) * quantity);
		return valueProduct;
	}
	
	public void updateProductsQuantityPurchases(int productCode, int quantity) {
		Productos p = new Productos();
		int productsQuantity = getProductsQuantity(productCode);
		p.setQuantity(productsQuantity);
		String sql = "UPDATE PRODUCTOS SET CANTIDAD_DISPONIBLE= (" + (productsQuantity + quantity)
				+ ") WHERE CODIGO_PRODUCTO= " + productCode + "";
		try (Connection conn = Conexion.realizarConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {
			ps.executeUpdate();
		} catch (Exception e) {
			System.out.println("Error actualizando la cantidad de productos " + e.getMessage());
		}

	}
	
	public double calculateValueTotal(double valuePurchases, double valueSales) {
		double valueProduct = (valuePurchases - valueSales);
		return valueProduct;
	}
	
	
}
