package comprasdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Conexion.Conexion;
import productosdto.Productos;

public class Compras extends Productos {

	public boolean insertarInformacionCompra(int codigoProducto, double valorCompra, int cantidad) {
		boolean compraRealizada = false;
		String sql = "INSERT INTO COMPRAS (CODIGO_PRODUCTO, PRECIO_COMPRA, CANTIDAD_COMPRADA) VALUES ('" + codigoProducto + "',"
				+ valorCompra + "," + cantidad + ")";
		try (Connection conn = Conexion.realizarConexion(); PreparedStatement ps = conn.prepareStatement(sql);) {
			int resultado = ps.executeUpdate();
			if (resultado == 1) {
				compraRealizada = true;
			}
		} catch (Exception e) {
			System.out.println("Ocurrio un error realizando el registro de la compra " + e.getMessage());
		}
		return compraRealizada;
	}
	
	public double getValuePurchases() {
		double valorCompra = 0;
		String sql = "SELECT SUM(PRECIO_COMPRA) FROM COMPRAS";
		try(Connection conn = Conexion.realizarConexion();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()){
			while(rs.next()) {
				valorCompra = rs.getInt(1);
			}
		}catch (Exception e) {
			System.out.println("Ocurrio un error consultando el valor de las ventas " + e.getMessage());
		}
		return valorCompra;
	}

}
