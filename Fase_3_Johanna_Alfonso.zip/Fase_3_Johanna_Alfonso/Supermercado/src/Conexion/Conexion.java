package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
	
	public static Connection realizarConexion() {
		Connection conn = null;
        String urlDb = "jdbc:mysql://localhost:3306/SUPERMERCADO";
		String user = "root";
		String password = "";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(urlDb, user, password);
			/*if(conn != null) {
				System.out.println("Conexi�n realizada");
			}*/
		} catch (Exception e) {
			System.out.println("Error realizando la conexi�n "+e.getMessage());
		}
		return conn;
	}
	//Connection Test
	/*public static void main(String[] args) {
		realizarConexion();
	}*/
}
