package triangulo;

public class TrianguloDto {
	
	private double medidaLado1;
	private double medidaLado2;
	private double medidaLado3;
	private boolean equilatero;
	private boolean lado1Mayor;
	private boolean lado2Mayor;
	private boolean lado3Mayor;
	private boolean ladosIguales;
	private boolean datosRegistrados;
	private boolean medidasComparadas;

	public boolean isMedidasComparadas() {
		return medidasComparadas;
	}

	public void setMedidasComparadas(boolean medidasComparadas) {
		this.medidasComparadas = medidasComparadas;
	}

	public boolean isDatosRegistrados() {
		return datosRegistrados;
	}

	public void setDatosRegistrados(boolean datosRegistrados) {
		this.datosRegistrados = datosRegistrados;
	}

	public boolean isLadosIguales() {
		return ladosIguales;
	}

	public void setLadosIguales(boolean ladosIguales) {
		this.ladosIguales = ladosIguales;
	}

	public boolean isEquilatero() {
		return equilatero;
	}

	public boolean isLado1Mayor() {
		return lado1Mayor;
	}

	public void setLado1Mayor(boolean lado1Mayor) {
		this.lado1Mayor = lado1Mayor;
	}

	public boolean isLado2Mayor() {
		return lado2Mayor;
	}

	public void setLado2Mayor(boolean lado2Mayor) {
		this.lado2Mayor = lado2Mayor;
	}

	public boolean isLado3Mayor() {
		return lado3Mayor;
	}

	public void setLado3Mayor(boolean lado3Mayor) {
		this.lado3Mayor = lado3Mayor;
	}

	public void setEquilatero(boolean equlatero) {
		this.equilatero = equlatero;
	}

	public double getMedidaLado1() {
		return medidaLado1;
	}

	public void setMedidaLado1(double medidaLado1) {
		this.medidaLado1 = medidaLado1;
	}

	public double getMedidaLado2() {
		return medidaLado2;
	}

	public void setMedidaLado2(double medidaLado2) {
		this.medidaLado2 = medidaLado2;
	}

	public double getMedidaLado3() {
		return medidaLado3;
	}

	public void setMedidaLado3(double medidaLado3) {
		this.medidaLado3 = medidaLado3;
	}

}
