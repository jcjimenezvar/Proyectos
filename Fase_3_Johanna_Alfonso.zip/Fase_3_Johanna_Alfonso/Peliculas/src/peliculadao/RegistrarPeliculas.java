package peliculadao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import conexion.Conexion;
import peliculadto.PeliculaDto;

public class RegistrarPeliculas {

	public boolean registrarInformacion(List<PeliculaDto> informationFilm) {
		boolean registrada = false;
		Connection conexion = null;
		PreparedStatement statement = null;
		String nombrePelicula = null;
		String generoPelicula = null;
		for (PeliculaDto dto : informationFilm) {
			nombrePelicula = dto.getNombrePeliclua();
			generoPelicula = dto.getGeneroPelicula();
		}
		String sql = "INSERT INTO PELICULAS (NOMBRE_PELICULA, GENERO_PELICULA) VALUES ('" + nombrePelicula + "','"
				+ generoPelicula + "')";
		try {
			conexion = Conexion.establecerConexion();
			statement = conexion.prepareStatement(sql);
			int resultado = statement.executeUpdate();
			if (resultado == 1) {
				registrada = true;
			}
		} catch (Exception e) {
			System.out.println("Error insertando la informaci�n de la pelicula " + e.getMessage());
		}
		return registrada;
	}
}
