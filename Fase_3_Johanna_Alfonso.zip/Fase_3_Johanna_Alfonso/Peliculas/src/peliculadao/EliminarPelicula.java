package peliculadao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import conexion.Conexion;

public class EliminarPelicula {

	public boolean eliminarInformacion(int idPelicula) throws SQLException {
		boolean eliminado = false;
		Connection conn = null;
		PreparedStatement ps = null;
		String sql = "DELETE FROM PELICULAS WHERE ID='" + idPelicula + "'";
		try {
			conn = Conexion.establecerConexion();
			ps = conn.prepareStatement(sql);
			int resultado = ps.executeUpdate();
			if (resultado == 1) {
				eliminado = true;
			}
		} catch (Exception e) {
			System.out.println("Error eliminando la pelicula " + e.getMessage());
		}finally {
			if(ps != null) {
				ps.close();
			}
			if(conn != null) {
				conn.close();
			}
		}
		return eliminado;
	}

}
