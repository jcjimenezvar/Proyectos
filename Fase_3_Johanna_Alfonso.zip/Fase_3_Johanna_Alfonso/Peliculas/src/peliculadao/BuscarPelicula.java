package peliculadao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import conexion.Conexion;

import peliculadto.PeliculaDto;;

public class BuscarPelicula {

	public List<PeliculaDto> obtenerListaPeliculas() throws SQLException {
		Connection conexion = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<PeliculaDto> listaPeliculas = new ArrayList<>();
		String sql = "SELECT ID, NOMBRE_PELICULA, GENERO_PELICULA FROM PELICULAS";
		try {
			conexion = Conexion.establecerConexion();
			ps = conexion.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				PeliculaDto dto = new PeliculaDto();
				dto.setIdPelicula(rs.getInt("ID"));
				dto.setNombrePeliclua(rs.getString("NOMBRE_PELICULA"));
				dto.setGeneroPelicula(rs.getString("GENERO_PELICULA"));
				listaPeliculas.add(dto);
			}
		} catch (Exception e) {
			System.out.println("Error consultando las peliculas" + e.getMessage());
		} finally {
			if(rs != null) {
				rs.close();
			}
			if(ps != null) {
				ps.close();
			}
			if(conexion != null) {
				conexion.close();
			}
		}
		return listaPeliculas;
	}

}
