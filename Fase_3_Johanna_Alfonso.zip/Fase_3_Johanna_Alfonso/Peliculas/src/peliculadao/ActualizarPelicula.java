package peliculadao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import conexion.Conexion;
import peliculadto.PeliculaDto;

public class ActualizarPelicula {
	
	public boolean actualizarPelicula(List<PeliculaDto> informacionPelicula, int id) throws SQLException {
		boolean updated = false;
		String nombrePelicula = null;
		String generoPelicula = null;
		Connection conn = null;
		PreparedStatement ps = null;
		for (PeliculaDto dto : informacionPelicula) {
			nombrePelicula = dto.getNombrePeliclua();
			generoPelicula = dto.getGeneroPelicula();
		}
		String sql = "UPDATE PELICULAS SET NOMBRE_PELICULA='"+nombrePelicula+"', GENERO_PELICULA='"+generoPelicula+"' WHERE ID='"+id+"'";
		try {
			conn = Conexion.establecerConexion();
			ps = conn.prepareStatement(sql);
			int result = ps.executeUpdate();
			if (result == 1) {
				updated = true;
			}
		} catch (Exception e) {
			System.out.println("Error actualizando la informaci�n de la pelicula " + e.getMessage());
		}finally {
			if(ps != null) {
				ps.close();
			}
			if(conn != null) {
				conn.close();
			}
		}
		return updated;
	}

}
