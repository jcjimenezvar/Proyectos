package conexion;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
	
	public static Connection establecerConexion() {
		Connection conexion = null;
        String url = "jdbc:mysql://localhost:3306/PELICULAS";
		String usuario = "root";
		String contrasena = "";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection(url, usuario, contrasena);			
		} catch (Exception e) {
			System.out.println("Error realizando la conexi�n "+e.getMessage());
		}
		return conexion;
	}
}
