package app;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import peliculadao.*;
import peliculadto.PeliculaDto;

public class Pelicula {

	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		Pelicula iniciar = new Pelicula();
		iniciar.cargarInformacion();
	}

	public void cargarInformacion() {
		int opc = 0;
		do {
			System.out.println("|**********************************|");
			System.out.println("|* 1. Registrar pelicula           |");
			System.out.println("|* 2. Actualizar pelicula          |");
			System.out.println("|* 3. Eliminar pelicula            |");
			System.out.println("|* 4. Salir                        |");
			System.out.println("|**********************************|");
			System.out.println("|* Seleccione la opci�n a realizar |");
			System.out.println("|**********************************|");
			opc = sc.nextInt();
			switch (opc) {
			case 1:
				List<PeliculaDto> informacionPelicula = aboutFilm();
				RegistrarPeliculas registrarPeliculas = new RegistrarPeliculas();
				boolean registered = registrarPeliculas.registrarInformacion(informacionPelicula);
				if (registered) {
					System.out.println("La pelicula fue registrada correctamente ");
				} else {
					System.out.println("No se pudo registrar la pelicula");
				}
				break;
			case 2:
				BuscarPelicula buscar = new BuscarPelicula();
				List<PeliculaDto> listaPeliculas = null;
				try {
					listaPeliculas = buscar.obtenerListaPeliculas();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				if (!listaPeliculas.isEmpty()) {

					for (PeliculaDto peliculasDisponibles : listaPeliculas) {
						System.out.println("|******************************************|");
						System.out.println("Codigo " + peliculasDisponibles.getIdPelicula() + " Nombre: "
								+ peliculasDisponibles.getNombrePeliclua() + " Genero: "
								+ peliculasDisponibles.getGeneroPelicula());
						System.out.println("|******************************************|");
					}
					System.out.println("|******************************************|");
					System.out.println("|* Ingrese el id de la pelicula a modificar ");
					System.out.println("|******************************************|");
					int id = sc.nextInt();
					List<PeliculaDto> informacionNuevaPelicula = aboutFilm();
					ActualizarPelicula actualizarPelicula = new ActualizarPelicula();
					boolean actualizada = false;
					try {
						actualizada = actualizarPelicula.actualizarPelicula(informacionNuevaPelicula, id);
					} catch (SQLException e) {
						e.printStackTrace();
					}
					if (actualizada) {
						System.out.println("Se actualizo de forma correcta la informaci�n de la pelicula");
					} else {
						System.out.println("Ocurrio un error actualizando la informaci�n de la pelicula");
					}

				} else {
					System.out.println("No existen peliculas disponibles para mostrar");
				}
				break;
			case 3:
				EliminarPelicula eliminarPelicula = new EliminarPelicula();
				BuscarPelicula peliculasEliminar = new BuscarPelicula();
				List<PeliculaDto> peliculasDisponibles = null;
				try {
					peliculasDisponibles = peliculasEliminar.obtenerListaPeliculas();
				} catch (SQLException e1) {					
					e1.printStackTrace();
				}
				if (!peliculasDisponibles.isEmpty()) {

					for (PeliculaDto eliminar : peliculasDisponibles) {
						System.out.println("|******************************************|");
						System.out.println("Codigo " + eliminar.getIdPelicula() + " Nombre: "
								+ eliminar.getNombrePeliclua() + " Genero: " + eliminar.getGeneroPelicula());
						System.out.println("|******************************************|");
					}
					System.out.println("|******************************************|");
					System.out.println("|* Ingrese el id de la pelicula a eliminar ");
					System.out.println("|******************************************|");
					int idPelicula = sc.nextInt();
					boolean eliminada = false;
					try {
						eliminada = eliminarPelicula.eliminarInformacion(idPelicula);
					} catch (SQLException e) {
						e.printStackTrace();
					}
					if (eliminada) {
						System.out.println("Se elimino de forma correcta la informaci�n de la pelicula");
					} else {
						System.out.println("Ocurrio un error eliminando la informaci�n de la pelicula");
					}
				} else {
					System.out.println("No existen peliculas disponibles para mostrar");
				}
				break;
			case 4:
				System.out.println("|******************************************|");
				System.out.println("|* Gracias por utilizar la aplicaci�n hasta pronto");
				System.out.println("|******************************************|");
				break;
			default:
				System.out.println("|******************************************|");
				System.out.println("|* Seleccione una opci�n valida del menu   |");
				System.out.println("|******************************************|");
				break;
			}
		} while (opc != 4);

	}

	public List<PeliculaDto> aboutFilm() {
		List<PeliculaDto> informacionPelicula = new ArrayList<>();
		PeliculaDto dto = new PeliculaDto();
		System.out.println("|**********************************|");
		System.out.println("|* Nombre de la pelicula           |");
		System.out.println("|**********************************|");
		String nombrePelicula = sc.next();
		dto.setNombrePeliclua(nombrePelicula);
		System.out.println("|**********************************|");
		System.out.println("|* Genero de la pelicula           |");
		System.out.println("|**********************************|");
		String generoPelicula = sc.next();
		dto.setGeneroPelicula(generoPelicula);
		informacionPelicula.add(dto);
		return informacionPelicula;
	}
}
