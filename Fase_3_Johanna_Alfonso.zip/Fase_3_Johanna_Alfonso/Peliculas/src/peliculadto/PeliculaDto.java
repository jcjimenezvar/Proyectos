package peliculadto;

public class PeliculaDto {

	private int idPelicula;
	private String nombrePeliclua;
	private String generoPelicula;

	public int getIdPelicula() {
		return idPelicula;
	}

	public void setIdPelicula(int idPelicula) {
		this.idPelicula = idPelicula;
	}

	public String getNombrePeliclua() {
		return nombrePeliclua;
	}

	public void setNombrePeliclua(String nombrePeliclua) {
		this.nombrePeliclua = nombrePeliclua;
	}

	public String getGeneroPelicula() {
		return generoPelicula;
	}

	public void setGeneroPelicula(String generoPelicula) {
		this.generoPelicula = generoPelicula;
	}

}
