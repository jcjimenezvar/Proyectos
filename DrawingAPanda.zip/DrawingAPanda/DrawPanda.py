import turtle


class DrawPanda:
    def __init__(self):
        print ("This is an application to draw a Panda Bear")
        config_pen()
        pass


t = turtle


def config_pen():
    myturtle = t.Turtle()
    myturtle.pensize(3)
    myturtle.speed(1)
    draw_face(myturtle)


def draw_face(myturtle):
    myturtle.color('black', 'black')
    myturtle.pendown()
    myturtle.circle(100)
    draw_rigth_ear(myturtle)


def draw_rigth_ear(myturtle):
    myturtle.penup()
    myturtle.setx(50)
    myturtle.sety(185)
    myturtle.pendown()
    myturtle.begin_fill()
    myturtle.right(90)
    myturtle.circle(30, -260)
    myturtle.end_fill()
    draw_left_ear(myturtle)


def draw_left_ear(myturtle):
    myturtle.penup()
    myturtle.setx(-50)
    myturtle.sety(185)
    myturtle.pendown()
    myturtle.left(170)
    myturtle.begin_fill()
    myturtle.right(90)
    myturtle.circle(30, 260)
    myturtle.end_fill()
    draw_left_eye(myturtle)


def draw_left_eye(myturtle):
    myturtle.penup()
    myturtle.setx(-40)
    myturtle.sety(90)
    myturtle.pendown()
    myturtle.begin_fill()
    myturtle.circle(30)
    myturtle.end_fill()
    myturtle.left(10)
    myturtle.penup()
    myturtle.setx(-30)
    myturtle.sety(110)
    myturtle.pendown()
    myturtle.color('white', 'white')
    myturtle.begin_fill()
    myturtle.circle(15)
    myturtle.end_fill()
    myturtle.penup()
    myturtle.setx(-30)
    myturtle.sety(115)
    myturtle.pendown()
    myturtle.color('black', 'black')
    myturtle.begin_fill()
    myturtle.circle(5)
    myturtle.end_fill()
    draw_right_eye(myturtle)


def draw_right_eye(myturtle):
    myturtle.penup()
    myturtle.setx(40)
    myturtle.sety(90)
    myturtle.pendown()
    myturtle.color('black', 'black')
    myturtle.begin_fill()
    myturtle.circle(30)
    myturtle.end_fill()
    myturtle.penup()
    myturtle.setx(30)
    myturtle.sety(110)
    myturtle.pendown()
    myturtle.color('white', 'white')
    myturtle.begin_fill()
    myturtle.circle(15)
    myturtle.end_fill()
    myturtle.penup()
    myturtle.setx(30)
    myturtle.sety(115)
    myturtle.pendown()
    myturtle.color('black', 'black')
    myturtle.begin_fill()
    myturtle.circle(5)
    myturtle.end_fill()
    draw_mouth_and_nose(myturtle)


def draw_mouth_and_nose(myturtle):
    myturtle.color('black', 'black')
    myturtle.penup()
    myturtle.setx(0)
    myturtle.sety(50)
    myturtle.pendown()
    myturtle.begin_fill()
    myturtle.circle(10)
    myturtle.end_fill()
    myturtle.right(90)
    myturtle.circle(20, 180)
    myturtle.penup()
    myturtle.setx(0)
    myturtle.sety(50)
    myturtle.pendown()
    myturtle.circle(20, -180)
    turtle.done()


if __name__ == '__main__':

    my_panda = DrawPanda()
    my_panda .__init__()



