﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Suma
{
    class Suma
    {
        static void Main(string[] args)
        {
            int i = 0;
            int o = 0;
            int s = 0;
            Console.WriteLine("Ingrese primer numero");
            i = int.Parse(Console.ReadLine()) ;
            Console.WriteLine("Ingrese segundo numero");
            o = int.Parse(Console.ReadLine());
            s = i + o;
            Console.WriteLine("La suma de estos dos números es: "+s);
            Console.ReadKey();
        }
    }
}
