package Connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexionDB {

	public static Connection obtenerConexion() {

		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/PruebaMuseo";
		String usuario = "postgres";
		String clave = "pgsql";
		try {
			Class.forName("org.postgresql.Driver");
			conn = DriverManager.getConnection(url, usuario, clave);
			/*if (conn != null) {
				System.out.println("Conexi�n Exitosa");
			}*/
		} catch (Exception e) {
			System.out.println("Error en la conexi�n: " + e.getMessage());
		}
		return conn;
	}

	/*public static void main(String[] args) {

		obtenerConexion();

	}*/

}
