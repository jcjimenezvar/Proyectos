package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Connection.ConexionDB;
import Dto.ArtistaDto;

public class ArtistaDao {

	String sql = "";

	public void listarArtistas() {

		sql = "select codigo, nombre, apellido from artistas ";
		try (Connection conn = ConexionDB.obtenerConexion();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				ArtistaDto dto = new ArtistaDto();
				dto.setCodigoArtista(rs.getString("codigo"));
				dto.setNombre(rs.getString("nombre"));
				dto.setApellido(rs.getString("apellido"));
				System.out.println("-- "+dto.getCodigoArtista() + " ---" + dto.getNombre() + " " + dto.getApellido());
			}

		} catch (Exception e) {
			System.out.println("Error al obtener los datos: " + e.getMessage());
		}

	}
	public void listarArtistaPorPintura(String codigoPintura) {

		sql = "select art.codigo, art.nombre, art.apellido from artistas as art, pinturas as pin "
				+ "where pin.codigo_artista=art.codigo and pin.codigo='"+codigoPintura+"'";
		try (Connection conn = ConexionDB.obtenerConexion();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				ArtistaDto dto = new ArtistaDto();
				dto.setCodigoArtista(rs.getString("codigo"));
				dto.setNombre(rs.getString("nombre"));
				dto.setApellido(rs.getString("apellido"));
				System.out.println("-- "+dto.getCodigoArtista() + " ---" + dto.getNombre() + " " + dto.getApellido());
			}

		} catch (Exception e) {
			System.out.println("Error al obtener los datos: " + e.getMessage());
		}

	}

}
