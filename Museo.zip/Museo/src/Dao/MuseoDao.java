package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import Connection.ConexionDB;
import Dto.MuseoDto;
import Dto.PinturaDto;

public class MuseoDao {
	
	String sql = "";

	public void listarMuseos() {

		sql = "select codigo, nombre from museos ";
		try (Connection conn = ConexionDB.obtenerConexion();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				MuseoDto dto = new MuseoDto();
				dto.setCodMuseo(rs.getString("codigo"));
				dto.setNombre(rs.getString("nombre"));				
				System.out.println("-- "+dto.getCodMuseo() + " ---" + dto.getNombre());
			}

		} catch (Exception e) {
			System.out.println("Error al obtener los datos: " + e.getMessage());
		}

	}
	public void calcularPrecioPinturas(String codMuseo) {
		sql = "select sum(pin.precio) from pinturas as pin, artistas as art, museos as mus "
				+ "where pin.codigo_artista=art.codigo and art.codigo= mus.codigo and mus.codigo = '"+codMuseo+"'";
		try (Connection conn = ConexionDB.obtenerConexion();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				PinturaDto dto = new PinturaDto();
				dto.setPrecio(rs.getInt("sum"));
				
				System.out.println("$ "+dto.getPrecio());
			}

		} catch (Exception e) {
			System.out.println("Error al obtener los datos: " + e.getMessage());
		}
	}
	

}
