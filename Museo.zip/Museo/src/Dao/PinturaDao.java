package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Connection.ConexionDB;
import Dto.PinturaDto;

public class PinturaDao {

	String sql = "";

	public void listarPinturasPorArtista(String codigoArtista) {

		sql = "select codigo, nombre, precio, fecha from pinturas where codigo_artista='" + codigoArtista + "'";
		try (Connection conn = ConexionDB.obtenerConexion();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				PinturaDto dto = new PinturaDto();
				dto.setCodigoPint(rs.getString("codigo"));
				dto.setNombre(rs.getString("nombre"));
				dto.setPrecio(rs.getInt("precio"));
				dto.setFecha(rs.getDate("fecha"));
				System.out.println("-- " + dto.getCodigoPint() + " -- " + dto.getNombre() + " -- " + dto.getPrecio()
						+ " -- " + dto.getFecha());
			}

		} catch (Exception e) {
			System.out.println("Error al obtener los datos: " + e.getMessage());
		}
	}

	public void listarPinturas() {
		sql = "select codigo, nombre, precio, fecha from pinturas";
		try (Connection conn = ConexionDB.obtenerConexion();
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				PinturaDto dto = new PinturaDto();
				dto.setCodigoPint(rs.getString("codigo"));
				dto.setNombre(rs.getString("nombre"));
				dto.setPrecio(rs.getInt("precio"));
				dto.setFecha(rs.getDate("fecha"));
				System.out.println("-- " + dto.getCodigoPint() + " -- " + dto.getNombre() + " -- " + dto.getPrecio()
						+ " -- " + dto.getFecha());
			}

		} catch (Exception e) {
			System.out.println("Error al obtener los datos: " + e.getMessage());
		}
	}
	
	
	
	
	

}
