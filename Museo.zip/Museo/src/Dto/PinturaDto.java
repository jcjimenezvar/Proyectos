package Dto;

import java.sql.Date;

public class PinturaDto {

	private String codigoPint;
	private String nombre;
	private int precio;
	private Date fecha;

	public String getCodigoPint() {
		return codigoPint;
	}

	public void setCodigoPint(String codigoPint) {
		this.codigoPint = codigoPint;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getPrecio() {
		return precio;
	}

	public void setPrecio(int precio) {
		this.precio = precio;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

}
