package Dto;

public class MuseoDto {

	private String codMuseo;
	private String nombre;
	private String direccion;

	public String getCodMuseo() {
		return codMuseo;
	}

	public void setCodMuseo(String codMuseo) {
		this.codMuseo = codMuseo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

}
