package App;

import java.util.Scanner;

import Dao.ArtistaDao;
import Dao.MuseoDao;
import Dao.PinturaDao;

public class MuseoApp {

	public static void main(String[] args) {

		MuseoDao museo = new MuseoDao();
		ArtistaDao artista = new ArtistaDao();
		PinturaDao pintura = new PinturaDao();
		Scanner sc = new Scanner(System.in);
		System.out.println("**************Bienvenido al museo**************");
		System.out.println("***********************************************");
		System.out.println("1.Conocer las pinturas de un artista           ");
		System.out.println("2.Conocer el artista de una obra seleccionada  ");
		System.out.println("3.Conocer el precio de las pinturas de un Museo");
		System.out.println("***********************************************");
		System.out.println(" Seleccione la operaci�n a ejecutar            ");
		System.out.println("***********************************************");
		int opc = sc.nextInt();
		switch (opc) {
		case 1:
			System.out.println("**************Lista de artistas*****************");
			System.out.println("************************************************");
			artista.listarArtistas();
			System.out.println("************************************************");
			System.out.println(" Seleccione el artista para conocer las pinturas");
			System.out.println("************************************************");
			String codArtista = sc.next();			
			System.out.println("************************************************");
			System.out.println(" Las pinturas del artista son:                  ");
			System.out.println("************************************************");
			pintura.listarPinturasPorArtista(codArtista);
			System.out.println("************************************************");
			break;
		case 2:
			System.out.println("**************Lista de pinturas*****************");
			System.out.println("************************************************");
			pintura.listarPinturas();
			System.out.println("************************************************");
			System.out.println(" Seleccione la pintura para conocer el artista  ");
			System.out.println("************************************************");
			String codPintura = sc.next();			
			System.out.println("************************************************");
			System.out.println(" El artista de la pintura es:                   ");
			System.out.println("************************************************");
			artista.listarArtistaPorPintura(codPintura);
			System.out.println("************************************************");
			break;
		case 3:
			System.out.println("**************Lista de Museos******************************");
			System.out.println("***********************************************************");
			museo.listarMuseos();
			System.out.println("***********************************************************");
			System.out.println(" Seleccione el museo para conocer el precio de las pinturas");
			System.out.println("***********************************************************");
			String codMuseo = sc.next();			
			System.out.println("***********************************************************");
			System.out.println(" El precio de las pinturas es:                  ");
			System.out.println("************************************************");
			museo.calcularPrecioPinturas(codMuseo);
			System.out.println("************************************************");
			break;

		default:
			break;
		}

	}

}
