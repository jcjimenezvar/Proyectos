'use strict';

const FS = require('fs');

exports.LoadFileView = function (req, res) {
    return res.view('loadFile/loadFile');
}

exports.LoadFile = async function (req, res) {
    let data = req.payload;
    let file = FS.createWriteStream("public/imagen1.png");

    await data.file.pipe(file);
    
    return res.redirect('/show-file/'+"imagen1.png");
}

exports.showImage = function (req, res) {
    let name_file = req.params.name;
    return res.view('loadFile/showImage', {srcImage : "/public/"+name_file});
} 