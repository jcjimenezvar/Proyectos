'use strict';

const HANDLERS = require('./handler');

module.exports = [{
        method: 'GET',
        path:'/load-file',
        config: { auth: false },
        handler: HANDLERS.LoadFileView
    },{
        method: 'POST',
        path:'/load-file',
        config: {
            payload: {
                allow: 'multipart/form-data',
                maxBytes: 209715200,
                output: 'stream',
                parse: true,
                timeout: 15000
            },
            auth: false
        },
        handler: HANDLERS.LoadFile
    },
    {
        method: 'GET',
        path:'/show-file/{name}',
        config: { auth: false },
        handler: HANDLERS.showImage
    }
]