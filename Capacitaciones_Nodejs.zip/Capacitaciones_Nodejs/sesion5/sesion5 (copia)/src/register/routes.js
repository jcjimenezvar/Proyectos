'use strict';

const HANDLERS = require('./handler');

module.exports = [{
        method: 'GET',
        path:'/register',
        config: { auth: false },
        handler: HANDLERS.registerView
    },{
        method: 'POST',
        path:'/register',
        config: { auth: false },
        handler: HANDLERS.register
    }
]