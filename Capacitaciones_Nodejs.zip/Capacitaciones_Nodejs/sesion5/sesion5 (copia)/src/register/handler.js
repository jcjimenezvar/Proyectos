'use strict';

const JOI = require('joi');


const schema = JOI.object().keys({
    username: JOI.string().alphanum().min(3).max(30).required(),
    name: JOI.string().regex(/^[a-zA-Z áéíóúñ]{3,30}$/),
    email: JOI.string().email(),
    password: JOI.string().regex(/^[a-zA-Z0-9]{3,30}$/)
});

exports.registerView = function (req, res) {
    return res.view('register/register');
}

exports.register = async function (req, res) {
    let obj = req.payload;
    let validation = JOI.validate(obj, schema);
    if (validation.error) return res.view('register/register', {error: validation});
    obj.password = await this.BCRYPT.hash(obj.password, this.BCRYPT_SALT);
    let user={
        username : obj.username,
        name : obj.name,
        password : obj.password,
        email: obj.email,
        rol : 1
    }
    await createUser(this.db,user);
    return res.view('register/register',{valid: true});
}

async function createUser(db,user) {
    let query = {
        name: 'fetch-user',
        text: 'INSERT INTO users(username,name,password,email,rol) VALUES($1,$2,$3,$4,$5)',
        values: [user.username,user.name,user.password,user.email,user.rol]
    }
    try {
        await db.query(query);
    } catch (err) {
        console.log(err);
    }
}