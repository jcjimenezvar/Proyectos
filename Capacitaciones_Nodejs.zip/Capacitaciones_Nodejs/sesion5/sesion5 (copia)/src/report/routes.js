'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [{
    method: 'GET',
    path: '/report/test',
    config: { auth: false },
    handler: HANDLERS.test
},{
    method: 'GET',
    path: '/report/ia',
    config: { auth: false },
    handler: HANDLERS.reportIAView
},{
    method: 'POST',
    path: '/report/ia',
    config: { auth: false },
    handler: HANDLERS.reportIA
}]