'use strict';

const REPORTER = require('excel-report');
const FS = require('fs');

exports.test = async function (req, res) {
    let template_file = __dirname + '/reports/people.xlsx';
    let mounths = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    let date = new Date();
    let data = {
        title: 'PERSONAL',
        date: date.getDate() + " de " + mounths[date.getMonth()] + " del " + date.getFullYear(),
        people: [
            { name: 'Manuel Nuñez', cedula: '1032434237' },
            { name: 'Andres Rodriguez', cedula: '1042545862' }
        ]
    };
    return new Promise(resolve => {
        REPORTER(template_file, data, function (err, binary) {
            if (err) {
                console.log(err);
                resolve(err);
            }
            resolve(new Buffer(binary, "binary"));
        });
    });
}

exports.reportIAView = function (req, res) {
    return res.view('report/ia_gestion');
}

exports.reportIA = async function (req, res) {
    console.log(req.payload);
    let format = req.payload.format;
    let limit = parseInt(req.payload.limit);
    let template_file = __dirname + '/reports/ia_gestion.xlsx';
    if (format == 'csv') {
        let report = FS.createWriteStream('./public/report.csv');
        report.write('ID IA,ID Gestion,Valor,Usuario,IP,Fecha Sys\n');
        report.end();
        let query = {
            text: "SELECT id_data_ia_gestion, valor, id_gestion, usuario_act, ip_act, to_char(fecha_hora_sis, 'DD Mon YYYY HH12:MI:SS') AS fecha_hora_sis FROM data_ia_gestion LIMIT $1 OFFSET $2",
            values: []
        }
        let partial;
        for (let i = 0; i < limit; i = i + 1000) {
            query.values[0] = (limit - i) > 1000 ? 1000 : (limit - i);
            query.values[1] = i;
            let data = (await this.db.query(query)).rows;
            console.log(query.values + '  ' + data.length);
            partial = '';
            for (let row = 0; row < data.length; row++) {
                partial = partial + data[row].id_data_ia_gestion + ',' + data[row].id_gestion + ',' + data[row].valor + ',' + data[row].usuario_act + ',' + data[row].ip_act + ',' + data[row].fecha_hora_sis + '\n';
            }
            FS.writeFileSync('./public/report.csv', partial, {flag: 'a'});
        }
        return res.file('report.csv', {
            mode: 'attachment',
            filename: 'report.csv'
        });
    } else {
        let query = {
            text: "SELECT id_data_ia_gestion, valor, id_gestion, usuario_act, ip_act, to_char(fecha_hora_sis, 'DD Mon YYYY HH12:MI:SS') AS fecha_hora_sis FROM data_ia_gestion LIMIT $1",
            values: [limit]
        }
        let data = { ia_gestion: (await this.db.query(query)).rows };
        return new Promise(resolve => {
            REPORTER(template_file, data, function (err, binary) {
                if (err) {
                    console.log(err);
                    resolve(err);
                }
                let buffer = new Buffer(binary, "binary");
                resolve(res.response(buffer).header('content-disposition', 'attachment; filename=report.xlsx;'));
            });
        });
    }
}