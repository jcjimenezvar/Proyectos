'use strict';

const HAPI = require('hapi');
const {Pool} = require('pg');
const INERT = require('inert');
const VISION = require('vision');
const PG = new Pool({
    connectionString: 'postgresql://postgres:postgres@10.10.10.151:5432/node'
});

const server = HAPI.server({ 
    host: 'localhost',
    port: 8000,
    routes: {
        files: {
            relativeTo: './public'
        }
    }
});

const start = async () => {
    await server.register([INERT, VISION]);
    
    server.views({
        engines: { hbs: require('handlebars') },
        relativeTo: __dirname,
        path: './views',
        layout: true,
        layoutPath: './views/layout',
        partialsPath: './views/partials',
        helpersPath: './views/helpers'
    });

    server.bind({
        db: PG
    });

    server.route(require('./src/general/routes'));
    server.route(require('./src/module1/routes'));
    
    await server.start();
    console.log('Server running at:', server.info.uri);
}

start();
