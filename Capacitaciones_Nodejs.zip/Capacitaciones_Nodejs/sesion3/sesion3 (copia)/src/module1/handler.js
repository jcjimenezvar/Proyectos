'use strict';

exports.home = function (req, res) {
    return res.view('module1/home');
}

exports.hello = function (req, res) {
    return 'hello world Node';
}

exports.html = function (req, res) {
    return res.file('hello.html');
}

exports.queryUsers = async function (req, res) {
    let query = {
        name: 'fetch-users',
        text: 'select username, name from users'
    }
    
    let user = await this.db.query(query);

    if(user){
        return user.rows;
    }else{
        return 'No hay usuarios registrados';
    }
}

exports.queryUser = async function (req, res) {
    let query = {
        name: 'fetch-users',
        text: 'select username, name from users where id = $1',
        values: [req.params.id]
    }
    
    let user = await this.db.query(query);

    if(user){
        return user.rows;
    }else{
        return 'No hay usuarios registrados';
    }
}

exports.sayHello = function (req, res) {
    return res.view('module1/sayHello', {name: req.params.name});
}