'use strict';

const HANDLERS = require('./handler');

module.exports = [{
        method: 'GET',
        path:'/', 
        handler: HANDLERS.home
    },{
        method: 'GET',
        path:'/hello', 
        handler: HANDLERS.hello
    },{
        method: 'GET',
        path:'/html', 
        handler: HANDLERS.html
    },{
        method: 'GET',
        path:'/users', 
        handler: HANDLERS.queryUsers
    },{
        method: 'GET',
        path:'/user/{id}', 
        handler: HANDLERS.queryUser
    },{
        method: 'GET',
        path:'/say-hello/{name}', 
        handler: HANDLERS.sayHello
    }
]