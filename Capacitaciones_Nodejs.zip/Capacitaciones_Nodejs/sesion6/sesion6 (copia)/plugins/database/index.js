'use strict';

const { Pool } = require("pg");
//const CONN_STRING = 'postgresql://postgres:postgres@10.10.10.151:5432/node';
var db;

const DATABASE = {
    name: 'database',
    register: function (server, options) {
        db = new Pool({
            connectionString: options.connectionString,
        })

        server.method({
            name: 'db.query',
            method: async (query) => {
                return await db.query(query);
            }
        });

        server.method({
            name: 'db.getUsers',
            method: async () => {
                let query = {
                    text: 'select id, name, username, password, rol, email from public.users',
                }
                return await db.query(query);
            }
        });

        server.method({
            name: 'db.getUserByName',
            method: async (userName) => {
                let query = {
                    text: 'SELECT name,id,password,rol,username FROM users WHERE username = $1',
                    values: [userName]
                }
                return await db.query(query);
            }
        });

        server.method({
            name: 'db.getUserById',
            method: async (id) => {
                let query = {
                    text: 'select username, name from users where id = $1',
                    values: [id]
                }
                return await db.query(query);
            }
        });

        server.method({
            name: 'db.storeLoginLog',
            method: (user_id,req) => {
                let query = {
                    text: 'INSERT INTO login_log(user_id,date,ip,browser) VALUES($1,now(),$2,$3)',
                    values: [user_id,req.info.remoteAddress,req.headers['user-agent']]
                }
                db.query(query);
            }
        });

        server.method({
            name: 'db.createUser',
            method: async (user) => {
                let query = {
                    text: 'INSERT INTO users(username,name,password,email,rol) VALUES($1,$2,$3,$4,$5)',
                    values: [user.username,user.name,user.password,user.email,user.rol]
                }
                await db.query(query);
            }
        });

        server.method({
            name: 'db.getDataIaGestion',
            method: async (limit,offset) => {
                let query = {
                    text: "SELECT id_data_ia_gestion, valor, id_gestion, usuario_act, ip_act, to_char(fecha_hora_sis, 'DD Mon YYYY HH12:MI:SS') AS fecha_hora_sis FROM data_ia_gestion LIMIT $1 OFFSET $2",
                    values: [limit,offset]
                }
                return await db.query(query);
            }
        });
    }
}

DATABASE.register.attributes = require('./package.json');
/*DATABASE.register.attributes = {  
    name: 'database',
    version: '1.0.0'
  }*/

module.exports = DATABASE