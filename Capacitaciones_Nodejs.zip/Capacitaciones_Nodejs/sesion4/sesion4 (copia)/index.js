'use strict';

const HAPI = require('hapi');
const {Pool} = require('pg');
const INERT = require('inert');
const VISION = require('vision');
const BCRYPT = require("bcrypt");
const BCRYPT_SALT = 10;
const JWT = require('jsonwebtoken');
const AUTH_COOKIE = require('hapi-auth-cookie');
const PASS_COOKIE = 'TTNlZBKxaxD/XBL5OU1flrzWHkaO/0uXfrhurtSbex4ZFR6dV5pMfYTva7pI18ZHxNO7K/e63bgpJtARbZha/CuunGV21mtB7tT18RxlNry350eHBHyOCzrHguL9IjxlDvsBbI0Kbo9KYV5JRcnZcI1kVR5MBL0AQ0y/adx1ZxosuWee+5+cfTYSRWaywwEO4LuABMNJ07lmyj2/JLuT77zs32uAigOYRHfal83JXxK0nBMdCSQjWlKoQelWrH9ih/2aK2ox4w0B/D9V5MKA8VV/NVL1o+9ZtxZKY/F9GRU+a/uooytdf+97AKngFvxgKkxIOC7vCrX5J+oW7zP+Zw==';
const SKJ = 'GdM1WBRLARhOJY5zRDINqr5kv+b6ixNGuocbt+3tN/M5TH31/b1sHMPhDErJhy1InL+R8nGuWxeUsUMissde877VWCCoxpWNnmgdJKMKe1N8qmfvscAwL/BLkZpuj9ByMD3UDOydtl9xXsjjYniiJ2Jq3gXLhb5fSHX3XCJ05/DBvdXlkdvt54qHqSswMip6O7Gpfvqq/uH1wHH+Z6jEJhmvUAb3LgNziT9TgGUSGrT8djJFiCqdNZbx36JZeps88YjM+nGDaoyjEZoxyrTbMy6qhzjavM0Ym6Upi4Ffa99avgpXx7tLPOjmKMQd+b2z87oUSVNMy1kdrpgNidxHDA==';
const TIME_OUT_SESSION = 30 * 60 * 1000; //30mins
const PG = new Pool({
    connectionString: 'postgresql://postgres:postgres@10.10.10.151:5432/node'
});

const server = HAPI.server({ 
    host: 'localhost',
    port: 8000,
    routes: {
        files: {
            relativeTo: './public'
        }
    }
});

const start = async () => {
    await server.register([INERT, VISION, AUTH_COOKIE]);

    const cache = server.cache({ segment: 'tokens', expiresIn: TIME_OUT_SESSION });
    server.app.cache = cache;
    server.auth.strategy('web', 'cookie', {
        password: PASS_COOKIE,
        cookie: 'sHapiJTCCIA',
        redirectTo: '/',
        isSecure: false,
        clearInvalid: true,
        redirectOnTry: false,
        validateFunc: async (req, session) => {
            const token = await cache.get(session.token);
            const out = {
                valid: !!token
            };
            if (!out.valid) {
                return out;
            }
            let dToken = null;
            let isValid = false;
            let exp = token.exp;
            if (exp) {
                if (exp > (new Date().getTime())) {
                    token.exp = new Date().getTime() + TIME_OUT_SESSION;
                    cache.set(session.token, token);
                    try {
                        dToken = JWT.decode(session.token);
                        isValid = true;
                    } catch (err) {
                        console.log(err);
                    }
                } else {
                    req.cookieAuth.clear();
                    out.valid = false;
                }
            }
            out.credentials = dToken;
            return out;
        }
    });
    server.auth.default('web');
    
    server.views({
        engines: { hbs: require('handlebars') },
        relativeTo: __dirname,
        path: './views',
        layout: true,
        layoutPath: './views/layout',
        partialsPath: './views/partials',
        helpersPath: './views/helpers'
    });

    server.bind({
        db: PG,
        JWT: JWT,
        SKJ: SKJ,
        BCRYPT: BCRYPT,
        TIME_OUT_SESSION: TIME_OUT_SESSION
    });

    server.route(require('./src/general/routes'));
    server.route(require('./src/auth/routes'));
    server.route(require('./src/module1/routes'));
    
    await server.start();
    console.log('Server running at:', server.info.uri);
}

start();
