'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [{
    method: 'POST',
    path: '/login',
    config: {
        auth: {
            strategy: 'web',
            mode: 'try'
        }
    },
    handler: HANDLERS.WebCheckLogin
},{
    method: 'GET',
    path: '/login',
    config: {
        auth: {
            strategy: 'web',
            mode: 'try'
        }
    },
    handler: HANDLERS.checkLoginView
},{

    method: 'GET',
    path: '/logout',
    handler: HANDLERS.webLogout
}]