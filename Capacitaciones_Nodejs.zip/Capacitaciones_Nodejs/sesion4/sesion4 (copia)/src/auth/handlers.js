'use strict';

exports.WebCheckLogin = async function (req, res) {
    try {
        let obj = req.payload;
        if (req.auth.isAuthenticated) {
            return res.redirect('/');
        }
        let dbUser = await queryUser(this.db,obj.username);
        if (!dbUser) {
            return res.redirect('/login');
        }
        let passOk = await this.BCRYPT.compare( obj.password, dbUser.password);
        if (passOk) {
            let session = {
                valid: true, // this will be set to false when the person logs out
                id: dbUser.id, // a random session id
                name: dbUser.name,
                username: dbUser.username,
                rol: dbUser.rol
            }
            let token = this.JWT.sign(session, this.SKJ);
            await req.server.app.cache.set(token, { username: session.username, exp: new Date().getTime()+ this.TIME_OUT_SESSION }, 0);
            await storeLoginLog(this.db,dbUser.id,req);
            req.cookieAuth.set({ token });
            req.auth.isAuthenticated = true;
            return res.redirect('/');
        } else {
            return res.redirect('/login');
        }
    } catch (error) {
        return res.redirect('/login');
    }
}

exports.checkLoginView = function (req, res) {
    return res.view('auth/login');
}

exports.webLogout = (req,res) => {
    req.cookieAuth.clear();
    return res.redirect('/');
};

async function queryUser(db,userName) {
    let query = {
        name: 'fetch-user',
        text: 'SELECT name,id,password,rol,username FROM users WHERE username = $1',
        values: [userName]
    }
    return (await db.query(query)).rows[0];
}

async function storeLoginLog(db,user_id,req) {
    let query = {
        name: 'store-login-log',
        text: 'INSERT INTO login_log(user_id,date,ip,browser) VALUES($1,now(),$2,$3)',
        values: [user_id,req.info.remoteAddress,req.headers['user-agent']]
    }
    try {
        await db.query(query);
    } catch (err) {
        console.log(err);
    }
}
