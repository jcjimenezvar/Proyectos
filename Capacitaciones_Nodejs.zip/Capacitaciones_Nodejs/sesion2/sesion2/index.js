'use strict';

const HAPI = require('hapi');
const {Pool} = require('pg');
const INERT = require('inert');
const PG = new Pool({
    connectionString: 'postgresql://postgres:postgres@10.10.10.151:5432/node'
});

const server = HAPI.server({ 
    host: 'localhost', 
    port: 8000,
    routes: {
        files: {
            relativeTo: './public'
        }
    }
});

const start = async () => {
    await server.register(INERT);
    
    await server.start();

    server.bind({
        db: PG
    });
    server.route(require('./routes.js'));
    console.log('Server running at:', server.info.uri);
}

start();
