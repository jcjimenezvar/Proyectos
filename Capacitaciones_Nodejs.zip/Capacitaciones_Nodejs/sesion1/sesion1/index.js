"use strict";

const HAPI = require('hapi');

const server = HAPI.server({ 
    host: 'localhost', 
    port: 8000 
});

server.route({
    method: 'GET',
    path:'/hello', 
    handler: function (request, h) {
        return 'hello world';
    }
});

server.start(function(err) {
    if (err) {
        console.log(err);
        process.exit(1);
    }
    console.log('Server running at:', server.info.uri);
});