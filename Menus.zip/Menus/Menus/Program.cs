﻿//Nombre del Autor: Olga Lucia Penagos Cubides
//Fecha: 2017-12-13
//Doy fe que este ejercicio es de mi autoría, en caso de encontrar plagio la nota de todo mi
//trabajo debe ser de CERO además de las respectivas sanciones a que haya lugar 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Menus
{
    class Program
    {
        string retornarMenuPrincipal = "S";
        int opcionConsulta;
        int numero;
        static void Main(string[] args)
        {
            Program inicio = new Program();
            inicio.accesoSistema();
        }
        public void accesoSistema()
        {
            int intentos = 1;
            int clave = 301303;
            int claveUsuario;
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("| Bienvenido al Software de aprendizaje 'UNAD'              |");
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("| Para acceder al programa debe ingresar la clave asignada  |");
            Console.WriteLine("| recuerde que solo tiene tres intentos, si falla la clave  |");
            Console.WriteLine("| sera bloqueada.                                           |");
            Console.WriteLine("|***********************************************************|");
            do
            {
                Console.WriteLine("|***********************************************************|");
                Console.WriteLine("| Por favor ingrese la clave;                               |");
                Console.WriteLine("|***********************************************************|");
                claveUsuario = int.Parse(Console.ReadLine());
                if (claveUsuario == clave)
                {
                    menuPrincipal();
                }
                else
                {
                    if (intentos != 3)
                    {
                        Console.Clear();
                        Console.WriteLine("|***********************************************************|");
                        Console.WriteLine("| Clave incorrecta, lleva " + intentos  + " intentos     |");
                        Console.WriteLine("|***********************************************************|");
                        intentos = intentos+1;
                    }
                    else
                    {
                        if (intentos == 3)
                        {
                            Console.Clear();
                            Console.WriteLine("|***********************************************************|");
                            Console.WriteLine("| Clave bloqueada, contactese con el administrador del      |");
                            Console.WriteLine("| sistema.                                                  |");
                            Console.WriteLine("|***********************************************************|");
                            break;
                        }
                    }
                }
            } while (claveUsuario != clave);
        }
        public void menuPrincipal()
        {
            do
            {
                Console.Clear();
                Console.WriteLine("|***********************************************************|");
                Console.WriteLine("|                    Menu de Opciones                       |");
                Console.WriteLine("|***********************************************************|");
                Console.WriteLine("| 1. Estructura del diagrama de Flujo.                      |");
                Console.WriteLine("| 2. Diferencia entre programación estructurada y programa- |");
                Console.WriteLine("| 3. Condicional Multiple.                                  |");
                Console.WriteLine("| 4. Ejemplo Condicional Multiple.                          |");
                Console.WriteLine("| 5. Definición de ciclos anidados.                         |");
                Console.WriteLine("| 6. Ejemplos de ciclos.                                    |");
                Console.WriteLine("| 7. Definición de Contador.                                |");
                Console.WriteLine("| 8. Ejemplo de contador.                                   |");
                Console.WriteLine("| 9. Defición de Acumulador                                 |");
                Console.WriteLine("| 10. Ejemplo de Acumulador                                 |");
                Console.WriteLine("| 11. Nombre del Autor- CEAD - Código                       |");
                Console.WriteLine("| 12. Salir                                                 |");
                Console.WriteLine("|***********************************************************|");
                Console.WriteLine("| Seleccione una opción:                                    |");
                Console.WriteLine("|***********************************************************|");
                opcionConsulta = int.Parse(Console.ReadLine());
                switch (opcionConsulta)
                {
                    case 1:
                        Console.Clear();
                        estructuraDiagramaFlujo();
                        break;
                    case 2:
                        Console.Clear();
                        diferenciasProgEstrucYProgOrienObj();
                        break;
                    case 3:
                        Console.Clear();
                        condicionalMultiple();
                        break;
                    case 4:
                        Console.Clear();
                        ejemploCondicionalMultiple();
                        break;
                    case 5:
                        Console.Clear();
                        definicionCiclosanidados();
                        break;
                    case 6:
                        Console.Clear();
                        ejemploCiclos();
                        break;
                    case 7:
                        Console.Clear();
                        definirContador();
                        break;
                    case 8:
                        Console.Clear();
                        ejemploContador();
                        break;
                    case 9:
                        Console.Clear();
                        definirAcumulador();
                        break;
                    case 10:
                        Console.Clear();
                        ejemploContador();
                        break;
                    case 11:
                        Console.Clear();
                        datosAutor();
                        break;
                    case 12:
                        Console.Clear();
                        abandonarPrograma();
                        break;
                }
            } while (opcionConsulta != 12);
        }
        public void estructuraDiagramaFlujo()
        {
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("|                Estructura del Diagrama                    |");
            Console.WriteLine("|                        de flujo                           |");
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("| La estructura esencial de la programación en la platafor- |");
            Console.WriteLine("| ma de Diseño Visual es el diagrama de flujo, que utiliza  |");
            Console.WriteLine("| por un lado Comandos, en los que se insertan diversas he- |");
            Console.WriteLine("| rramientas (fuentes, funciones, indicadores, variables) y |");
            Console.WriteLine("| por otro Operadores. Todos estos elementos se relacionan  |");
            Console.WriteLine("| por medio de los conectores a través de los puntos de en- |");
            Console.WriteLine("| lace.                                                     |");
            Console.WriteLine("|***********************************************************|");
            retornarMenu();
        }
        public void diferenciasProgEstrucYProgOrienObj()
        {
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("|  Programación Estructurada  | Programación Orientada a    |");
            Console.WriteLine("|                             |         Objetos             |");
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("|*Encapsula datos (atributos) |*Estan Orientados a accion-  |");
            Console.WriteLine("| y metodos (comportamiento)  | es.                         |");
            Console.WriteLine("| en objetos que están rela-  |                             |");
            Console.WriteLine("| cionados entre si.          |*La unidad de programación   |");
            Console.WriteLine("|*La unidad de programación   | es la Función.              |");
            Console.WriteLine("| es la clase                 |                             |");
            Console.WriteLine("|***********************************************************|");
            retornarMenu();
        }
        public void condicionalMultiple()
        {
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("|                Condicional Multiple                       |");
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("| Las estructuras de comparación múltiples, son tomas de    |");
            Console.WriteLine("| decisión especializadas que permiten comparar una         |");
            Console.WriteLine("| variable contra distintos posibles resultados, ejecutando |");
            Console.WriteLine("| para cada caso una serir de instrucciones especificas.    |");
            Console.WriteLine("|***********************************************************|");
            retornarMenu();
        }
        public void ejemploCondicionalMultiple()
        {
            int num1;
            int num2;
            Console.WriteLine("Ingrese el primer numero");
            num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el segundo numero");
            num2 = int.Parse(Console.ReadLine());
            int suma = num1 + num2;
            if (suma < 10)
            {
                Console.WriteLine("El numero es menor a diez");
            }
            else
            {
                if (suma > 10)
                {
                    Console.WriteLine("El numero es mayor a diez");
                }
                else
                {
                    Console.WriteLine("El numero esta entre cero y diez");
                }
            }
            retornarMenu();
        }
        public void definicionCiclosanidados()
        {
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("|                  Ciclos Anidados                          |");
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("| Un ciclo anidado es un ciclo que contiene otro ciclo.     |");
            Console.WriteLine("| Tenemos 3 ciclos diferentes el ciclo while, do_while y    |");
            Console.WriteLine("| for, estos ciclos se pueden anidar uno en otro ya sea el  |");
            Console.WriteLine("| mismo ciclo o uno diferente.                              |");
            Console.WriteLine("|***********************************************************|");
            retornarMenu();
        }
        public void ejemploCiclos()
        {
            do
            {
                Console.Clear();
                Console.WriteLine("|***********************************************************|");
                Console.WriteLine("|                  Ejemplos de Ciclos                       |");
                Console.WriteLine("|***********************************************************|");
                Console.WriteLine("| 1. Ciclo para (FOR)                                       |");
                Console.WriteLine("| 2. Ciclo mientras (WHILE)                                 |");
                Console.WriteLine("| 3. Ciclo repita si (DO WHILE)                             |");
                Console.WriteLine("| 4. Retornar al menu principal                             |");
                Console.WriteLine("|***********************************************************|");
                Console.WriteLine("| Ingrese la opcion de la que desea conocer el ejemplo:     |");
                Console.WriteLine("|***********************************************************|");
                opcionConsulta = int.Parse(Console.ReadLine());
                switch (opcionConsulta)
                {
                    case 1:
                        Console.Clear();
                        for (int i = 0; i < 11; i++)
                        {
                            Console.WriteLine("***********");
                            Console.WriteLine("*    " + i + "    *");
                            Console.WriteLine("**********");
                        }
                        Console.ReadKey();
                        break;
                    case 2:                        
                        Console.Clear();
                        while (numero <= 10)
                        {
                            Console.WriteLine("Ingrese un numero menor o igual a 10");
                            numero = int.Parse(Console.ReadLine());
                        }
                        Console.ReadKey();
                        break;
                    case 3:
                        Console.Clear();
                        do
                        {
                            Console.WriteLine("Ingrese un numero menor o igual a 10");
                            numero = int.Parse(Console.ReadLine());
                        } while (numero <= 10);
                        Console.ReadKey();
                        break;
                    case 4:
                        Console.Clear();
                        Console.WriteLine("|***********************************************************|");
                        Console.WriteLine("| Gracias por consultar esta opción.                        |");
                        Console.WriteLine("|***********************************************************|");
                        break;
                }
            } while (opcionConsulta != 4);
        }
        public void definirContador()
        {
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("|                  Definción Contador                       |");
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("| Un contador es una variable que se incrementará en una    |");
            Console.WriteLine("| unidad cada vez que se ejecute el proceso.                |");
            Console.WriteLine("| Se utiliza para llevar la cuenta de determinadas acciones |");
            Console.WriteLine("| que se pueden solicitar durante la resolución de un pro-  |");
            Console.WriteLine("| blema.                                                    |");
            Console.WriteLine("|***********************************************************|");
            retornarMenu();
        }
        public void ejemploContador()
        {
            for (int numero = 0; numero < 100; numero++)
            {
                Console.WriteLine(numero);
            }   
            retornarMenu();
        }
        public void definirAcumulador()
        {
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("|                  Definción Acumulador                     |");
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("| Un Acumulador es una variable en la memoria cuya misión   |");
            Console.WriteLine("| es almacenar cantidades variables.                        |");
            Console.WriteLine("| Se utiliza para efectuar sumas sucesivas. La principal    |");
            Console.WriteLine("| diferencia con el contador es que el incremento o decre-  |");
            Console.WriteLine("| mento de cada suma es variable en lugar de constante como |");
            Console.WriteLine("| en el caso del contador.                                  |");
            Console.WriteLine("|***********************************************************|");
            retornarMenu();
        }
        public void ejemploAcumulador()
        {
            int a = 0;
            for (int i = 1; i <= 10; i++)
            {
                a = a + i;
            }
            retornarMenu();
        }
        public void datosAutor()
        {
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("| Nombre: Olga Lucia Penagos Cubides                        |");
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("| CEAD: Jose Acevedo y Gomez                                |");
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("| Código: 52'194.937                                        |");
            Console.WriteLine("|***********************************************************|");
            retornarMenu();
        }
        public void abandonarPrograma()
        {
            Console.WriteLine("|***********************************************************|");
            Console.WriteLine("| Gracias por utilizar el programa, hasta pronto.           |");
            Console.WriteLine("|***********************************************************|");
        }
        public void retornarMenu()
        {
            do
            {
                Console.WriteLine("|***********************************************************|");
                Console.WriteLine("|Presione S para volver al menu Principal                   |");
                Console.WriteLine("|***********************************************************|");
                retornarMenuPrincipal = Console.ReadLine().ToUpper();
            } while (!retornarMenuPrincipal.Equals("S"));
        }
    }
}
