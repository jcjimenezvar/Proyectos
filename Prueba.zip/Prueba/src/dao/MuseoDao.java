package dao;

public class MuseoDao {

}
