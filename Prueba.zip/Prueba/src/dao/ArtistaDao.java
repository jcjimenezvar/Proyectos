package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conexion.Conexion;
import dto.ArtistasDto;

public class ArtistaDao {
	
	public List<ArtistasDto> obtenerListaArtistas() throws SQLException{
		List<ArtistasDto> listaArtistas = new ArrayList<>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sentencia = "SELECT codigo, nombre, apellido from artistas";
		try {
			conn = Conexion.realizarConexion();
			ps = conn.prepareStatement(sentencia);
			rs = ps.executeQuery();
			while(rs.next()) {
				ArtistasDto dto = new ArtistasDto();
				dto.setCodigo(rs.getInt("codigo"));
				dto.setNombre(rs.getString("nombre"));
				dto.setApellido(rs.getString("apellido"));
				listaArtistas.add(dto);
			}
		} catch (Exception e) {
			System.out.println("Error obteniendo la lista de artistas "+e.getMessage());
		}finally {
			if(rs != null) {
				rs.close();
			}
			if(ps != null) {
				ps.close();
			}
			if(conn != null) {
				conn.close();
			}
		}
		return listaArtistas;		
	}
}
