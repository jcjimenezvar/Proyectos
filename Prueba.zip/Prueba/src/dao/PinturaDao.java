package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conexion.Conexion;
import dto.PinturasDto;

public class PinturaDao {

	public List<PinturasDto> pinturaArtista(int codigoArt) throws SQLException {
		List<PinturasDto> listaPinturas = new ArrayList<>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sentencia = "SELECT codigo, nombre, precio, fecha from pinturas where codigo_artista='" + codigoArt
				+ "'";
		try {
			conn = Conexion.realizarConexion();
			ps = conn.prepareStatement(sentencia);
			rs = ps.executeQuery();
			while (rs.next()) {
				PinturasDto dto = new PinturasDto();
				dto.setCodigo(rs.getInt(1));
				dto.setNombre(rs.getString(2));
				dto.setPrecio(rs.getInt(3));
				dto.setFecha(rs.getString(4));
				listaPinturas.add(dto);
			}
		} catch (Exception e) {
			System.out.println("Error obteniendo la lista de pinturas " + e.getMessage());
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (ps != null) {
				ps.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return listaPinturas;

	}

}
