package conexion;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

	public static Connection realizarConexion() {
		Connection conexion = null;
		String urlDB ="jdbc:postgresql://localhost/PruebaMuseo";
		String usuario = "postgres";
		String contrasena = "pgsql";
		try {
			Class.forName("org.postgresql.Driver");
			conexion = DriverManager.getConnection(urlDB, usuario, contrasena);
			if(conexion!=null) {
				System.out.println("Conexi�n exitosa");
			}
		} catch (Exception e) {
			System.out.println("Error realizando la conexi�n "+e.getMessage());
		}
		return conexion;
	}

	public static void main(String[] args) {
		realizarConexion();	
	}

}
