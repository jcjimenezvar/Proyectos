package app;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import dao.ArtistaDao;
import dao.PinturaDao;
import dto.ArtistasDto;
import dto.PinturasDto;

public class Museo {

	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);
		System.out.println("1. Pinturas por artista");
		System.out.println("2. Artista que pinto");
		System.out.println("3. Valor pinturas museo");
		System.out.println("Seleccione la opci�n a ejecutar");
		String entrada = sc.next();
		switch (entrada) {
		case "1":
			ArtistaDao listar = new ArtistaDao();
			List<ArtistasDto> lista = listar.obtenerListaArtistas();
			System.out.println("lista de artistas");
			for (ArtistasDto artistasDto : lista) {
				System.out.println(
						artistasDto.getCodigo() + "-" + artistasDto.getNombre() + "-" + artistasDto.getApellido());
			}
			System.out.println("Seleccione el artista para la conocer las pinturas");
			int codigoArt = Integer.parseInt(sc.next());
			PinturaDao dao = new PinturaDao();
			List<PinturasDto> pinturas = dao.pinturaArtista(codigoArt);
			System.out.println("Las pinturas del artista son :");
			for (PinturasDto pinturaDto : pinturas) {
				System.out.println(pinturaDto.getCodigo() + "-" + pinturaDto.getNombre() + "-" + pinturaDto.getPrecio()
						+ "-" + pinturaDto.getFecha());
			}
			break;
		case "2":

			break;
		case "3":

			break;

		}

	}

}
