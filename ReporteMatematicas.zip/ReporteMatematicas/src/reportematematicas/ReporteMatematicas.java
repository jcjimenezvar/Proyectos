package reportematematicas;

import java.util.Scanner;

public class ReporteMatematicas {

    final int FILAS = 3;
    final int COLUMNAS = 3;

    int[][] matriz = new int[FILAS][COLUMNAS];
    Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        ReporteMatematicas reporteMatematicas = new ReporteMatematicas();
        reporteMatematicas.callMethods();
    }

    public void callMethods() {
        int opc;
        do {
            System.out.println("|******************************|");
            System.out.println("|1 Ingresar notas estudiantes  |");
            System.out.println("|2 Mostrar notas estudiantes   |");
            System.out.println("|3 Promedio notas estudiantes  |");
            System.out.println("|4 Calificación mas alta       |");
            System.out.println("|5 Calificación mas baja       |");
            System.out.println("|6 Salir                       |");
            System.out.println("|******************************|");
            System.out.println("|Seleccione un opción          |");
            System.out.println("|******************************|");
            opc = sc.nextInt();
            switch (opc) {
                case 1:
                    captura(matriz, FILAS, COLUMNAS);
                    break;
                case 2:
                    imprimir(matriz, FILAS, COLUMNAS);
                    break;
                case 3:
                    promedio(matriz, FILAS, COLUMNAS);
                    break;
                case 4:
                    calificacionMasAlta(matriz, FILAS);
                    break;
                case 5:
                    calificacionMasBaja(matriz, FILAS);
                    break;
                case 6:
                    System.out.println("Gracias por utilizar el programa");
                    break;
                default:
                    System.out.println("Ingrese una opción valida del menu ");
                    break;
            }
        } while (opc != 6);

    }

    public void captura(int matriz[][], int filas, int columnas) {
        for (int i = 0; i < FILAS; i++) {
            System.out.println("Fila #: " + (i + 1));
            for (int j = 0; j < COLUMNAS; j++) {
                System.out.println("Ingrese la nota para el estudiante: " + (j + 1));
                matriz[i][j] = sc.nextInt();
            }
        }
        return;
    }

    public void imprimir(int matriz[][], int filas, int columnas) {
        for (int i = 0; i < FILAS; i++) {
            System.out.println("Fila #: " + (i + 1));
            for (int j = 0; j < COLUMNAS; j++) {
                System.out.println("Las notas para el estudiante " + (j + 1) + " son: " + matriz[i][j]);
            }
        }
    }

    public void promedio(int matriz[][], int filas, int columnas) {
        int promedio = 0;
        int totalNotas = 0;
        for (int i = 0; i < FILAS; i++) {
            totalNotas = 0;
            System.out.println("Promedio Notas Fila #: " + (i + 1));
            for (int j = 0; j < COLUMNAS; j++) {
                totalNotas = totalNotas + matriz[i][j];
            }
            promedio = totalNotas / COLUMNAS;
            System.out.println("Promedio : " + promedio);
        }
    }

    public void calificacionMasAlta(int matriz[][], int filas) {
        for (int i = 0; i < FILAS; i++) {
            System.out.println("Fila #: " + (i + 1));
            if (matriz[i][0] > matriz[i][1] && matriz[i][0] > matriz[i][2]) {
                System.out.println("La nota mas alta es " + matriz[i][0]);
            } else if (matriz[i][1] > matriz[i][0] && matriz[i][1] > matriz[i][2]) {
                System.out.println("La nota mas alta es " + matriz[i][1]);
            } else {
                System.out.println("La nota mas alta es " + matriz[i][2]);
            }
        }
    }

    public void calificacionMasBaja(int matriz[][], int filas) {
        for (int i = 0; i < FILAS; i++) {
            System.out.println("Fila #: " + (i + 1));
            if (matriz[i][0] < matriz[i][1] && matriz[i][0] < matriz[i][2]) {
                System.out.println("La nota mas baja es " + matriz[i][0]);
            } else if (matriz[i][1] < matriz[i][0] && matriz[i][1] < matriz[i][2]) {
                System.out.println("La nota mas baja es " + matriz[i][1]);
            } else {
                System.out.println("La nota mas baja es " + matriz[i][2]);
            }
        }
    }
}
