package nomina;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Nomina {

    Scanner sc = new Scanner(System.in);

    final double DESCUENTOPENSION = 0.04;
    final double DESCUENTOSALUD = 0.04;

    public static void main(String[] args) {
        Nomina nomina = new Nomina();
        nomina.menuOpciones();
    }

    public void menuOpciones() {
        int opc;
        List<Empleados> listaEmpleados = new ArrayList<>();
        do {
            System.out.println("|************************|");
            System.out.println("|1. Registrar empleados  |");
            System.out.println("|2. Consultar nomina     |");
            System.out.println("|3. Salir                |");
            System.out.println("|************************|");
            System.out.println("|Seleccione un opción    |");
            System.out.println("|************************|");
            opc = sc.nextInt();
            switch (opc) {
                case 1:
                    listaEmpleados = registrarEmpleados();
                    break;
                case 2:
                    consultarNomina(listaEmpleados);
                    break;
                case 3:
                    System.out.println("|**********************************|");
                    System.out.println("| Gracias por utilizar el programa |");
                    System.out.println("|**********************************|");
                    break;
                default:
                    System.out.println("|***************************************|");
                    System.out.println("| Seleccione una opción valida del menu |");
                    System.out.println("|***************************************|");
                    break;
            }

        } while (opc != 3);
    }

    public List<Empleados> registrarEmpleados() {
        List<Empleados> empleadosList = new ArrayList<>();
        Empleados empleados;
        System.out.println("|**********************************************|");
        System.out.println("| Ingrese la cantidad de empleados a registrar |");
        System.out.println("|**********************************************|");
        int cantidad = sc.nextInt();
        for (int i = 0; i < cantidad; i++) {
            empleados = new Empleados();
            System.out.println("|********************************|");
            System.out.println(" Ingrese el nombre del empleado " + (i + 1));
            System.out.println("|********************************|");
            String nombre = sc.next();
            empleados.setNombre(nombre);
            System.out.println("|***********************************|");
            System.out.println(" Ingrese el apellido del empleado " + (i + 1));
            System.out.println("|***********************************|");
            String apellido = sc.next();
            empleados.setApellido(apellido);
            System.out.println("|***********************************|");
            System.out.println(" Ingrese el salario del empleado " + (i + 1));
            System.out.println("|***********************************|");
            double salario = sc.nextInt();
            empleados.setSalario(salario);
            double descuentoSS = (salario * DESCUENTOPENSION) + (salario * DESCUENTOSALUD);
            empleados.setDeducciones(descuentoSS);
            double totalPago = (salario - descuentoSS) + empleados.SUBSIDIO;
            empleados.setTotalPago(totalPago);
            empleadosList.add(empleados);
        }
        return empleadosList;
    }

    public void consultarNomina(List<Empleados> empleadosList) {
        double totalNomina = 0;
        for (Empleados emp : empleadosList) {
            System.out.println("|******************************************************************************|");
            System.out.println(" Total a pagar para el empleado " + emp.getNombre() + " " + emp.getApellido() + ", Valor: " + emp.getTotalPago());
            System.out.println("|******************************************************************************|");
            System.out.println("");
            totalNomina = totalNomina + emp.getTotalPago();
        }
        System.out.println("|*********************************************|");
        System.out.println(" El valor total a pagar de nomina es :" + totalNomina);
        System.out.println("|*********************************************|");
    }

}
