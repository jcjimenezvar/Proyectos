package controladores;

import ejb.ClientesFacadeLocal;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import modelo.Clientes;
import modelo.Empleados;

@Named
@SessionScoped

public class ConsultarClientesControlador implements Serializable {

    @EJB
    private ClientesFacadeLocal ejbClientes;
    private Clientes clientes;
    private List<Clientes> listaClientes;

    public Clientes getClientes() {
        return clientes;
    }

    public void setClientes(Clientes clientes) {
        this.clientes = clientes;
    }

    public List<Clientes> getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(List<Clientes> listaClientes) {
        this.listaClientes = listaClientes;
    }

    @PostConstruct
    public void init() {
        listaClientes = ejbClientes.findAll();
        this.cargarOpcionesCliente();
    }

    public void leerCliente(Clientes clienteEditar) {
        clientes = clienteEditar;
    }

    public String cargarOpcionesCliente() {
        String redireccion;
        Empleados em = (Empleados) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("empleado");
        switch (Integer.parseInt(em.getRol())) {
            case 0:
                redireccion = "/principal/cajero/consultaClientes?faces-redirect=true";
                break;
            case 1:
                redireccion = "/principal/empleado/consultaClientes?faces-redirect=true";
                break;
            default:
                redireccion = "/index?faces-redirect=true";
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Error", "No hay opción para el rol seleccionado"));
                break;
        }
        return redireccion;
    }

    public void modificar() {
        try {
            ejbClientes.edit(clientes);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Cliente Modificado", "Se ha modificado correctamente el cliente"));
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Error", "No se pudo modificar el cliente"));
        }

    }

    public void eliminar() {
        try {
            ejbClientes.remove(clientes);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Cliente eliminado", "El cliente fue eliminado correctamente"));
            listaClientes = ejbClientes.findAll();
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Error", "No se pudo eliminar el cliente"));
        }
    }

}
