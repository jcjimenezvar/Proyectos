package controladores;

import ejb.ClientesFacadeLocal;
import ejb.ReparacionesFacadeLocal;
import ejb.TipoCalzadoFacadeLocal;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import modelo.Clientes;
import modelo.Empleados;
import modelo.Reparaciones;
import modelo.ReparacionesPorCliente;
import modelo.TipoCalzado;

@Named
@SessionScoped
public class ConsultarReparacionesControlador implements Serializable {

    @EJB
    private ClientesFacadeLocal ejbCliente;
    @EJB
    private ReparacionesFacadeLocal ejbReparaciones;
    @EJB
    private TipoCalzadoFacadeLocal ejbTipoCalzado;
    private List<Clientes> listaClientes;
    private List<Reparaciones> listaReparaciones;
    private List<TipoCalzado> listaTipoCalzado;
    private List<ReparacionesPorCliente> reparacionesPorCliente;
    private Clientes clientes;
    private Reparaciones reparaciones;
    private ReparacionesPorCliente reparacionesPorClienteObj;
    private TipoCalzado tipoCalzado;
    private double valorReparacion;
    private String tipoCalzadoStr;

    public List<Clientes> getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(List<Clientes> listaClientes) {
        this.listaClientes = listaClientes;
    }

    public List<Reparaciones> getListaReparaciones() {
        return listaReparaciones;
    }

    public void setListaReparaciones(List<Reparaciones> listaReparaciones) {
        this.listaReparaciones = listaReparaciones;
    }

    public Clientes getClientes() {
        return clientes;
    }

    public void setClientes(Clientes clientes) {
        this.clientes = clientes;
    }

    public Reparaciones getReparaciones() {
        return reparaciones;
    }

    public void setReparaciones(Reparaciones reparaciones) {
        this.reparaciones = reparaciones;
    }

    public double getValorReparacion() {
        return valorReparacion;
    }

    public void setValorReparacion(double valorReparacion) {
        this.valorReparacion = valorReparacion;
    }

    public List<TipoCalzado> getListaTipoCalzado() {
        return listaTipoCalzado;
    }

    public void setListaTipoCalzado(List<TipoCalzado> listaTipoCalzado) {
        this.listaTipoCalzado = listaTipoCalzado;
    }

    public TipoCalzado getTipoCalzado() {
        return tipoCalzado;
    }

    public void setTipoCalzado(TipoCalzado tipoCalzado) {
        this.tipoCalzado = tipoCalzado;
    }

    public List<ReparacionesPorCliente> getReparacionesPorCliente() {
        return reparacionesPorCliente;
    }

    public void setReparacionesPorCliente(List<ReparacionesPorCliente> reparacionesPorCliente) {
        this.reparacionesPorCliente = reparacionesPorCliente;
    }

    public String getTipoCalzadoStr() {
        return tipoCalzadoStr;
    }

    public void setTipoCalzadoStr(String tipoCalzadoStr) {
        this.tipoCalzadoStr = tipoCalzadoStr;
    }

    public ReparacionesPorCliente getReparacionesPorClienteObj() {
        return reparacionesPorClienteObj;
    }

    public void setReparacionesPorClienteObj(ReparacionesPorCliente reparacionesPorClienteObj) {
        this.reparacionesPorClienteObj = reparacionesPorClienteObj;
    }

    @PostConstruct
    public void init() {
        tipoCalzado = new TipoCalzado();
        reparaciones = new Reparaciones();
        reparacionesPorClienteObj = new ReparacionesPorCliente();
        listaTipoCalzado = ejbTipoCalzado.findAll();
        this.cargarPaginaReparaciones();
        this.llenarListaReparacionesCliente();
    }

    public void leerReparacion(ReparacionesPorCliente reparacionEditar) {
        reparacionesPorClienteObj = reparacionEditar;
    }

    public String cargarPaginaReparaciones() {
        String redireccion;
        Empleados em = (Empleados) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("empleado");
        switch (Integer.parseInt(em.getRol())) {
            case 0:
                redireccion = "/principal/cajero/consultaReparacion?faces-redirect=true";
                break;
            case 1:
                redireccion = "/principal/empleado/consultaReparacion?faces-redirect=true";
                break;
            default:
                redireccion = "/index?faces-redirect=true";
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Error", "No hay opción para el rol seleccionado"));
                break;
        }
        return redireccion;
    }

    public void llenarListaReparacionesCliente() {
        try {
            listaClientes = ejbCliente.findAll();
            listaReparaciones = ejbReparaciones.findAll();
            reparacionesPorCliente = combinarListas(listaClientes, listaReparaciones);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public List<ReparacionesPorCliente> combinarListas(List<Clientes> c, List<Reparaciones> r) {
        List<ReparacionesPorCliente> rpc = new ArrayList<>();
        try {
            r.forEach((Reparaciones rep) -> {
                c.stream().filter((cli) -> (rep.getIdentificacionCliente().equals(cli.getIdentificacion()))).map((cli) -> {
                    ReparacionesPorCliente reparacion = new ReparacionesPorCliente();
                    reparacion.setIdentificacionCliente(cli.getIdentificacion());
                    reparacion.setNombres(cli.getNombres());
                    reparacion.setApellidos(cli.getApellidos());
                    reparacion.setTelefono(cli.getTelefono());
                    reparacion.setDireccion(cli.getDireccion());
                    return reparacion;
                }).map((reparacion) -> {
                    reparacion.setDescripcion(rep.getDescripcion());
                    return reparacion;
                }).map((reparacion) -> {
                    reparacion.setValorReparacion(rep.getValorReparacion());
                    return reparacion;
                }).map((reparacion) -> {
                    reparacion.setEstadoReparacion(rep.getEstadoReparacion());
                    return reparacion;
                }).map((reparacion) -> {
                    reparacion.setId(rep.getId());
                    return reparacion;
                }).forEachOrdered((reparacion) -> {
                    rpc.add(reparacion);
                });
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        return rpc;
    }

    public void modificar() {
        try {
            tipoCalzado.setId(Short.parseShort(tipoCalzadoStr));
            reparaciones.setDescripcion(reparacionesPorClienteObj.getDescripcion());
            reparaciones.setEstadoReparacion(reparacionesPorClienteObj.isEstadoReparacion());
            reparaciones.setIdentificacionCliente(reparacionesPorClienteObj.getIdentificacionCliente());
            reparaciones.setIdTipoCalzado(tipoCalzado);
            reparaciones.setValorReparacion(reparacionesPorClienteObj.getValorReparacion());
            ejbReparaciones.edit(reparaciones);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Reparación Modificada", "Se ha modificado correctamente la reparación"));
        } catch (Exception e) {
            e.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Error", "No se pudo modificar la reparación"));
        }
    }

    public void eliminar() {
        try {
            boolean eliminado = ejbReparaciones.delete(reparacionesPorClienteObj);
            if (eliminado) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Reparación eliminada", "La reparación fue eliminada correctamente"));
                llenarListaReparacionesCliente();
            }else{
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Error", "No se pudo eliminar la reparación"));
            }
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Error", "No se pudo eliminar la reparación"));
        }
    }

}
