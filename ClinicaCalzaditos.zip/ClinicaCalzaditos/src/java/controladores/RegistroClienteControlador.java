package controladores;

import ejb.ClientesFacadeLocal;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import modelo.Clientes;

@Named
@SessionScoped
public class RegistroClienteControlador implements Serializable {

    @EJB
    private ClientesFacadeLocal ejbClientes;
    private Clientes clientes;
    private List<Clientes> listaClientes;
    private final boolean ESTADO_USUARIO = true;

    public Clientes getClientes() {
        return clientes;
    }

    public void setClientes(Clientes clientes) {
        this.clientes = clientes;
    }

    public List<Clientes> getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(List<Clientes> listaClientes) {
        this.listaClientes = listaClientes;
    }

    @PostConstruct
    public void init() {
        clientes = new Clientes();
    }

    public void registrarCliente() {
        try {
            listaClientes = ejbClientes.findAll();
            boolean yaRegistrado = false;
            for (Clientes c : listaClientes) {
                if (c.getIdentificacion().equals(clientes.getIdentificacion())) {
                    yaRegistrado = true;
                }
            }
            if (yaRegistrado) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Cliente registrado", "El cliente ya se encuentra registrado"));
            } else {
                clientes.setEstado(ESTADO_USUARIO);
                ejbClientes.create(clientes);
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro Correcto", "Se registro correctamente el cliente"));
            }
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Error", "Error registrando el cliente"));
        }

    }

}
