package controladores;

import java.io.Serializable;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import modelo.Empleados;

@Named
@ViewScoped
public class AccesosControlador implements Serializable {

    public void verificarSesion() {
        try {
            FacesContext context = FacesContext.getCurrentInstance();
            Empleados em = (Empleados) context.getExternalContext().getSessionMap().get("empleado");
            if (em == null) {
                context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Permisos Insuficientes", ""));
                context.getExternalContext().redirect("./../index.xhtml");
            }
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Permisos Insuficientes", ""));
        }

    }

}
