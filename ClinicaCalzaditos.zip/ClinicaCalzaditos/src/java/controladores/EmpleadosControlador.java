package controladores;

import ejb.EmpleadosFacadeLocal;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import modelo.Empleados;

@Named
@ViewScoped
public class EmpleadosControlador implements Serializable {

    @EJB
    private EmpleadosFacadeLocal ejbEmpleado;
    private Empleados empleado;

    public Empleados getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleados empleado) {
        this.empleado = empleado;
    }
    
    @PostConstruct
    public void init(){
        empleado = new Empleados();
    }
    
    public String iniciarSesion(){
        Empleados em;
        String redireccion = null;
        try {
            em = ejbEmpleado.iniciarSesion(empleado);
            if (em != null) {
                FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("empleado", em);
                redireccion = "/principal/principal?faces-redirect=true";
            } else {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Usuario o contraseña incorrecta", ""));
            }
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", ""));
        }
        return redireccion;
    }

     
     
     
     
     

}
