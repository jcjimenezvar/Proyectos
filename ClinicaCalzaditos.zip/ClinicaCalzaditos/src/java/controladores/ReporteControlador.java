package controladores;

import ejb.ClientesFacadeLocal;
import ejb.ReparacionesFacadeLocal;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.model.SelectItem;
import javax.faces.model.SelectItemGroup;
import javax.inject.Named;
import modelo.Clientes;
import modelo.Reparaciones;

@Named
@SessionScoped
public class ReporteControlador implements Serializable {

    @EJB
    private ClientesFacadeLocal ejbClientes;
    @EJB
    private ReparacionesFacadeLocal ejbReparaciones;

    private List<SelectItem> reportes;
    private String tipoReporte;
    private List<Clientes> listaClientes;
    private List<Reparaciones> listaReparaciones;

    public List<SelectItem> getReportes() {
        return reportes;
    }

    public void setReportes(List<SelectItem> reportes) {
        this.reportes = reportes;
    }

    public String getTipoReporte() {
        return tipoReporte;
    }

    public void setTipoReporte(String tipoReporte) {
        this.tipoReporte = tipoReporte;
    }

    public List<Clientes> getListaClientes() {
        return listaClientes;
    }

    public void setListaClientes(List<Clientes> listaClientes) {
        this.listaClientes = listaClientes;
    }

    public List<Reparaciones> getListaReparaciones() {
        return listaReparaciones;
    }

    public void setListaReparaciones(List<Reparaciones> listaReparaciones) {
        this.listaReparaciones = listaReparaciones;
    }

    @PostConstruct
    public void init() {
        SelectItemGroup opcionesReportes = new SelectItemGroup();
        opcionesReportes.setSelectItems(new SelectItem[]{new SelectItem("1", "Clientes"), new SelectItem("2", "Reparaciones")});
        reportes = new ArrayList<>();
        reportes.add(opcionesReportes);
    }

    public void cargarTablas() {
        switch (tipoReporte) {
            case "1":
                listaClientes = ejbClientes.findAll();
                break;
            case "2":
                listaReparaciones = ejbReparaciones.findAll();
                break;
        }

    }

}
