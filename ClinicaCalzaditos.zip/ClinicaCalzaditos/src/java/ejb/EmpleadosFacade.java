package ejb;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import modelo.Empleados;

@Stateless
public class EmpleadosFacade extends AbstractFacade<Empleados> implements EmpleadosFacadeLocal {

    @PersistenceContext(unitName = "ClinicaCalzaditosPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public EmpleadosFacade() {
        super(Empleados.class);
    }

    @Override
    public Empleados iniciarSesion(Empleados emp) {
        Empleados empleados = null;
        String consulta;
        try {
            consulta = "FROM Empleados e WHERE e.identificacion=?1 AND e.cotrasena=?2";
            Query query = em.createQuery(consulta);
            query.setParameter(1, emp.getIdentificacion());
            query.setParameter(2, emp.getCotrasena());
            List<Empleados> lista = query.getResultList();
            if (!lista.isEmpty()) {
                empleados = lista.get(0);
            }
        } catch (Exception e) {
            throw e;
        }
        return empleados;
    }

}
