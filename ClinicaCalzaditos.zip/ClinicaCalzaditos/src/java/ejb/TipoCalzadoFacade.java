/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import modelo.TipoCalzado;

/**
 *
 * @author Familia_JimenezDuque
 */
@Stateless
public class TipoCalzadoFacade extends AbstractFacade<TipoCalzado> implements TipoCalzadoFacadeLocal {

    @PersistenceContext(unitName = "ClinicaCalzaditosPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TipoCalzadoFacade() {
        super(TipoCalzado.class);
    }
    
}
