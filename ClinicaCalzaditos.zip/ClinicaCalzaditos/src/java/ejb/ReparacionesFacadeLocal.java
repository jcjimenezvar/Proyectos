package ejb;

import java.util.List;
import javax.ejb.Local;
import modelo.Reparaciones;
import modelo.ReparacionesPorCliente;

@Local
public interface ReparacionesFacadeLocal {

    void create(Reparaciones reparaciones);

    void edit(Reparaciones reparaciones);

    void remove(Reparaciones reparaciones);

    Reparaciones find(Object id);

    List<Reparaciones> findAll();

    List<Reparaciones> findRange(int[] range);

    int count();
    
    boolean delete(ReparacionesPorCliente r);
    
}
