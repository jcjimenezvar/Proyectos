/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Familia_JimenezDuque
 */
@Entity
@Table(name = "reparaciones")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Reparaciones.findAll", query = "SELECT r FROM Reparaciones r")
    , @NamedQuery(name = "Reparaciones.findById", query = "SELECT r FROM Reparaciones r WHERE r.id = :id")
    , @NamedQuery(name = "Reparaciones.findByValorReparacion", query = "SELECT r FROM Reparaciones r WHERE r.valorReparacion = :valorReparacion")
    , @NamedQuery(name = "Reparaciones.findByIdentificacionCliente", query = "SELECT r FROM Reparaciones r WHERE r.identificacionCliente = :identificacionCliente")
    , @NamedQuery(name = "Reparaciones.findByDescripcion", query = "SELECT r FROM Reparaciones r WHERE r.descripcion = :descripcion")
    , @NamedQuery(name = "Reparaciones.findByEstadoReparacion", query = "SELECT r FROM Reparaciones r WHERE r.estadoReparacion = :estadoReparacion")})
public class Reparaciones implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Short id;
    @Basic(optional = false)
    @NotNull
    @Column(name = "VALOR_REPARACION")
    private double valorReparacion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "IDENTIFICACION_CLIENTE")
    private String identificacionCliente;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "DESCRIPCION")
    private String descripcion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ESTADO_REPARACION")
    private boolean estadoReparacion;
    @JoinColumn(name = "ID_TIPO_CALZADO", referencedColumnName = "ID")
    @ManyToOne(optional = false)
    private TipoCalzado idTipoCalzado;

    public Reparaciones() {
    }

    public Reparaciones(Short id) {
        this.id = id;
    }

    public Reparaciones(Short id, double valorReparacion, String identificacionCliente, String descripcion, boolean estadoReparacion) {
        this.id = id;
        this.valorReparacion = valorReparacion;
        this.identificacionCliente = identificacionCliente;
        this.descripcion = descripcion;
        this.estadoReparacion = estadoReparacion;
    }

    public Short getId() {
        return id;
    }

    public void setId(Short id) {
        this.id = id;
    }

    public double getValorReparacion() {
        return valorReparacion;
    }

    public void setValorReparacion(double valorReparacion) {
        this.valorReparacion = valorReparacion;
    }

    public String getIdentificacionCliente() {
        return identificacionCliente;
    }

    public void setIdentificacionCliente(String identificacionCliente) {
        this.identificacionCliente = identificacionCliente;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean getEstadoReparacion() {
        return estadoReparacion;
    }

    public void setEstadoReparacion(boolean estadoReparacion) {
        this.estadoReparacion = estadoReparacion;
    }

    public TipoCalzado getIdTipoCalzado() {
        return idTipoCalzado;
    }

    public void setIdTipoCalzado(TipoCalzado idTipoCalzado) {
        this.idTipoCalzado = idTipoCalzado;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reparaciones)) {
            return false;
        }
        Reparaciones other = (Reparaciones) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.Reparaciones[ id=" + id + " ]";
    }
    
}
