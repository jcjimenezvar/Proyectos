package modelo;

import java.util.Date;

public class ReparacionesPorCliente {

    private short id;
    private double valorReparacion;
    private String identificacionCliente;
    private String descripcion;
    private boolean estadoReparacion;
    private TipoCalzado idTipoCalzado;
    private String nombres;
    private String apellidos;
    private Date fechaNacimiento;
    private String telefono;
    private String direccion;

    public short getId() {
        return id;
    }

    public void setId(short id) {
        this.id = id;
    }

    public double getValorReparacion() {
        return valorReparacion;
    }

    public void setValorReparacion(double valorReparacion) {
        this.valorReparacion = valorReparacion;
    }

    public String getIdentificacionCliente() {
        return identificacionCliente;
    }

    public void setIdentificacionCliente(String identificacionCliente) {
        this.identificacionCliente = identificacionCliente;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isEstadoReparacion() {
        return estadoReparacion;
    }

    public void setEstadoReparacion(boolean estadoReparacion) {
        this.estadoReparacion = estadoReparacion;
    }

    public TipoCalzado getIdTipoCalzado() {
        return idTipoCalzado;
    }

    public void setIdTipoCalzado(TipoCalzado idTipoCalzado) {
        this.idTipoCalzado = idTipoCalzado;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

}
