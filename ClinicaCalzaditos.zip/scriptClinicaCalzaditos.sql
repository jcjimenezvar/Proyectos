CREATE DATABASE clinicaCalzaditos

CREATE TABLE EMPLEADOS(
	id INT AUTO_INCREMENT PRIMARY KEY,
	identificacion VARCHAR(100) NOT NULL,		
	nombres VARCHAR(100) NOT NULL,
	apellidos VARCHAR(100) NOT NULL,
	edad INT NOT NULL,
	direccion VARCHAR(100) NOT NULL,
	estado BOOL DEFAULT TRUE NOT NULL,
	cotrasena VARCHAR(100) not null,
	rol Enum ('0','1')
);

INSERT INTO `clinicacalzaditos`.`empleados` (`id`, `identificacion`, `nombres`, `apellidos`, `edad`, `direccion`) VALUES ('1', '109845678', 'Carlos', 'Medina', '28', 'Cra 21 15-02');
UPDATE `clinicacalzaditos`.`empleados` SET `cotrasena`='clave', `rol`='0' WHERE  `id`=1;
INSERT INTO `clinicacalzaditos`.`empleados` (`id`, `identificacion`, `nombres`, `apellidos`, `edad`, `direccion`, `cotrasena`, `rol`) VALUES ('2', '2874963', 'Andres', 'Cortes', '25', 'Cra 34 17-80', 'clave', '1');


CREATE TABLE MENU(
	codigo TINYINT PRIMARY KEY,
	nombre_menu VARCHAR(50) not null,		
	url VARCHAR(100),
	tipo_menu ENUM('S','I') not null,
	rol_usuario ENUM('0','1') not null,
	codigo_submenu TINYINT,
	estado BOOL DEFAULT TRUE NOT NULL
);

INSERT INTO MENU (codigo, nombre_menu,url,tipo_menu, rol_usuario, codigo_submenu)
VALUES 
(1,'Registro',null,'S','0',null),
(2,'Clientes','/faces/principal/cajero/registroClientes.xhtml','I','0',1),
(3,'Reparacion','/faces/principal/cajero/registroReparacion.xhtml','I','0',1),
(4,'Consulta',null,'S','1',null),
(5,'Clientes','/faces/principal/empleado/consultaClientes.xhtml','I','1',4),
(6,'Reparaciones','/faces/principal/empleado/consultaReparacion.xhtml','I','1',4),
(7,'Consulta',null,'S','0',null),
(8,'Clientes','/faces/principal/cajero/consultaClientes.xhtml','I','0',7),
(9,'Reparaciones','/faces/principal/cajero/consultaReparacion.xhtml','I','0',7),
(10,'Informe',null,'S','0',null),
(11,'Reparaciones','/faces/principal/cajero/generarInformeReparacion.xhtml','I','0',10);

CREATE TABLE CLIENTES(
	id INT AUTO_INCREMENT PRIMARY KEY,
	identificacion VARCHAR(50) NOT NULL,		
	nombres VARCHAR(100) NOT NULL,
	apellidos VARCHAR(100) NOT NULL,
	fecha_nacimiento DATE NOT NULL,
	telefono VARCHAR(100) NOT NULL,
	direccion VARCHAR(100) NOT NULL,
	estado BOOL DEFAULT TRUE NOT NULL
);


CREATE TABLE TIPO_CALZADO(
	ID TINYINT AUTO_INCREMENT PRIMARY KEY,
	NOMBRE_CALZADO VARCHAR(50) NOT NULL,		
	ESTADO BOOL DEFAULT TRUE NOT NULL
);

CREATE TABLE REPARACIONES(
	ID TINYINT AUTO_INCREMENT PRIMARY KEY,
	VALOR_REPARACION DOUBLE NOT NULL,
	IDENTIFICACION_CLIENTE VARCHAR(50) NOT NULL,
	DESCRIPCION VARCHAR(200) NOT NULL,		
	ID_TIPO_CALZADO TINYINT NOT NULL,
	ESTADO_REPARACION BOOL DEFAULT TRUE NOT NULL
);

ALTER TABLE REPARACIONES ADD CONSTRAINT FK_ID_TIPO_CALZADO FOREIGN KEY (ID_TIPO_CALZADO) REFERENCES TIPO_CALZADO (ID);

INSERT INTO `clinicacalzaditos`.`tipo_calzado` (`ID`, `NOMBRE_CALZADO`) VALUES ('1', 'Zapato Dama');
INSERT INTO `clinicacalzaditos`.`tipo_calzado` (`ID`, `NOMBRE_CALZADO`) VALUES ('2', 'Zapato Caballero');
INSERT INTO `clinicacalzaditos`.`tipo_calzado` (`ID`, `NOMBRE_CALZADO`) VALUES ('3', 'Tennis');




